cmake_minimum_required(VERSION 3.20)
project(CubeDashAndroid)
add_subdirectory(SDL)
add_subdirectory(cd)
