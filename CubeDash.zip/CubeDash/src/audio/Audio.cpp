#include "Audio.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <cstdlib>

#ifdef CD_HAS_FMOD
#include <fmod.hpp>
#include <fmod_errors.h>
#endif

namespace cd {

#ifdef CD_HAS_FMOD

struct Audio::Impl {
    FMOD::System* sys = nullptr;
    FMOD::ChannelGroup *master = nullptr, *gMusic = nullptr, *gSfx = nullptr;
    FMOD::Sound* music = nullptr;
    FMOD::Channel* mch = nullptr;
    FMOD::Sound* sfx[9] = {};
};

static std::string fmodErr(FMOD_RESULT r) { return std::string(FMOD_ErrorString(r)); }

Audio::Audio() : d(new Impl) {}
Audio::~Audio() { shutdown(); delete d; }

static FMOD::Sound* makeSfx(FMOD::System* sys, float seconds, const std::function<float(float)>& fn) {
    const int rate = 44100;
    const unsigned n = (unsigned)(seconds * rate);
    FMOD_CREATESOUNDEXINFO ex;
    std::memset(&ex, 0, sizeof(ex));
    ex.cbsize = sizeof(ex);
    ex.length = n * sizeof(int16_t);
    ex.numchannels = 1;
    ex.defaultfrequency = rate;
    ex.format = FMOD_SOUND_FORMAT_PCM16;
    FMOD::Sound* s = nullptr;
    if (sys->createSound(nullptr, FMOD_OPENUSER | FMOD_CREATESAMPLE | FMOD_LOOP_OFF, &ex, &s) != FMOD_OK) return nullptr;
    void *p1 = nullptr, *p2 = nullptr;
    unsigned l1 = 0, l2 = 0;
    if (s->lock(0, ex.length, &p1, &p2, &l1, &l2) != FMOD_OK) { s->release(); return nullptr; }
    int16_t* o = (int16_t*)p1;
    for (unsigned i = 0; i < n && i * 2 < l1; i++) {
        float t = (float)i / rate;
        float v = std::max(-1.f, std::min(1.f, fn(t)));
        o[i] = (int16_t)(v * 32000.f);
    }
    s->unlock(p1, p2, l1, l2);
    return s;
}

bool Audio::init() {
    if (ready) return true;
    if (FMOD::System_Create(&d->sys) != FMOD_OK) return false;
    if (d->sys->init(64, FMOD_INIT_NORMAL, nullptr) != FMOD_OK) { d->sys->release(); d->sys = nullptr; return false; }
    d->sys->getMasterChannelGroup(&d->master);
    d->sys->createChannelGroup("music", &d->gMusic);
    d->sys->createChannelGroup("sfx", &d->gSfx);
    d->master->addGroup(d->gMusic);
    d->master->addGroup(d->gSfx);
    const float PI2 = 6.2831853f;
    auto env = [](float t, float dur) { float k = t / dur; return (k < .05f ? k / .05f : 1.f) * std::exp(-3.f * k); };
    d->sfx[(int)Sfx::Jump] = makeSfx(d->sys, .10f, [&](float t) {
        float f = 380 + 2400 * t; return .35f * std::sin(PI2 * f * t) * env(t, .10f); });
    d->sfx[(int)Sfx::Death] = makeSfx(d->sys, .40f, [&](float t) {
        float f = 320 - 650 * t; float n = ((std::rand() % 2000) / 1000.f - 1.f);
        return (.25f * std::sin(PI2 * f * t) + .22f * n) * env(t, .40f); });
    d->sfx[(int)Sfx::Coin] = makeSfx(d->sys, .20f, [&](float t) {
        float f = t < .08f ? 988.f : 1480.f; return .3f * std::sin(PI2 * f * t) * env(std::fmod(t, .08f), .12f); });
    d->sfx[(int)Sfx::Pad] = makeSfx(d->sys, .14f, [&](float t) {
        float f = 300 + 4500 * t; return .3f * std::sin(PI2 * f * t) * env(t, .14f); });
    d->sfx[(int)Sfx::Orb] = makeSfx(d->sys, .12f, [&](float t) {
        return .3f * std::sin(PI2 * (700 + 60 * std::sin(PI2 * 30 * t)) * t) * env(t, .12f); });
    d->sfx[(int)Sfx::Portal] = makeSfx(d->sys, .22f, [&](float t) {
        float f = 200 + 3600 * t; return .28f * std::sin(PI2 * f * t) * env(t, .22f); });
    d->sfx[(int)Sfx::Win] = makeSfx(d->sys, .6f, [&](float t) {
        static const float n[4] = {523.f, 659.f, 784.f, 1047.f};
        int i = std::min(3, (int)(t / .13f)); return .3f * std::sin(PI2 * n[i] * t) * env(std::fmod(t, .13f), .3f); });
    d->sfx[(int)Sfx::Flip] = makeSfx(d->sys, .09f, [&](float t) {
        float f = 900 - 5000 * t; return .3f * std::sin(PI2 * f * t) * env(t, .09f); });
    d->sfx[(int)Sfx::Click] = makeSfx(d->sys, .04f, [&](float t) { return .25f * std::sin(PI2 * 1200 * t) * env(t, .04f); });
    ready = true;
    applyVolumes();
    return true;
}

void Audio::shutdown() {
    if (!d || !d->sys) return;
    unloadMusic();
    for (auto& s : d->sfx) if (s) { s->release(); s = nullptr; }
    d->sys->close();
    d->sys->release();
    d->sys = nullptr;
    ready = false;
}

void Audio::applyVolumes() {
    if (!ready) return;
    d->master->setVolume(vMaster);
    d->gMusic->setVolume(vMusic);
    d->gSfx->setVolume(vSfx);
}

void Audio::setVolumes(float m, float mu, float sf) { vMaster = m; vMusic = mu; vSfx = sf; applyVolumes(); }

void Audio::update(float dt) {
    if (!ready) return;
    d->sys->update();
    if (delay > 0) {
        delay -= dt;
        if (delay <= 0) { delay = 0; playMusic(0.f); }
    }
}

bool Audio::loadMusic(const std::string& p, std::string* err) {
    if (!ready) { if (err) *err = "Audio engine not running"; return false; }
    if (musicLoaded && p == path) return true;
    unloadMusic();
    FMOD_RESULT r = d->sys->createSound(p.c_str(), FMOD_CREATESTREAM | FMOD_LOOP_OFF | FMOD_ACCURATETIME, nullptr, &d->music);
    if (r != FMOD_OK) { if (err) *err = fmodErr(r); d->music = nullptr; return false; }
    unsigned ms = 0;
    d->music->getLength(&ms, FMOD_TIMEUNIT_MS);
    length = ms / 1000.f;
    path = p;
    musicLoaded = true;

    // Waveform peaks (decoded in a second, non-streaming handle).
    peakData.clear();
    FMOD::Sound* dec = nullptr;
    if (d->sys->createSound(p.c_str(), FMOD_OPENONLY | FMOD_ACCURATETIME, nullptr, &dec) == FMOD_OK && dec) {
        FMOD_SOUND_TYPE type; FMOD_SOUND_FORMAT fmt; int chans = 1, bits = 16;
        dec->getFormat(&type, &fmt, &chans, &bits);
        unsigned pcm = 0;
        dec->getLength(&pcm, FMOD_TIMEUNIT_PCM);
        int bps = fmt == FMOD_SOUND_FORMAT_PCMFLOAT || fmt == FMOD_SOUND_FORMAT_PCM32 ? 4 :
                  fmt == FMOD_SOUND_FORMAT_PCM24 ? 3 : fmt == FMOD_SOUND_FORMAT_PCM8 ? 1 : 2;
        const int buckets = 1600;
        chans = std::max(1, chans);
        const unsigned long long total = (unsigned long long)pcm;
        peakData.assign(buckets, 0.f);
        if (total > 0) {
            std::vector<unsigned char> buf(1 << 16);
            unsigned long long frame = 0;
            const unsigned frameBytes = bps * chans;
            for (;;) {
                unsigned got = 0;
                FMOD_RESULT rr = dec->readData(buf.data(), (unsigned)buf.size(), &got);
                if (got == 0 && rr != FMOD_OK) break;
                if (got == 0) break;
                for (unsigned off = 0; off + frameBytes <= got; off += frameBytes, frame++) {
                    float m = 0;
                    for (int c = 0; c < chans; c++) {
                        const unsigned char* q = &buf[off + c * bps];
                        float v;
                        if (fmt == FMOD_SOUND_FORMAT_PCMFLOAT) { float f; std::memcpy(&f, q, 4); v = f; }
                        else if (fmt == FMOD_SOUND_FORMAT_PCM8) v = ((int)q[0] - 128) / 128.f;
                        else if (fmt == FMOD_SOUND_FORMAT_PCM24) v = (int32_t)((q[0] << 8) | (q[1] << 16) | ((unsigned)q[2] << 24)) / 2147483648.f;
                        else if (fmt == FMOD_SOUND_FORMAT_PCM32) { int32_t i; std::memcpy(&i, q, 4); v = i / 2147483648.f; }
                        else { int16_t s; std::memcpy(&s, q, 2); v = s / 32768.f; }
                        m = std::max(m, std::fabs(v));
                    }
                    size_t b = std::min<size_t>(buckets - 1, (size_t)(frame * buckets / total));
                    peakData[b] = std::max(peakData[b], m);
                }
                if (got < buf.size()) break;
            }
            float mx = 0.0001f;
            for (float v : peakData) mx = std::max(mx, v);
            for (float& v : peakData) v /= mx;
        }
        dec->release();
    }
    return true;
}

void Audio::unloadMusic() {
    if (!d) return;
    stopMusic();
    if (d->music) { d->music->release(); d->music = nullptr; }
    musicLoaded = false; path.clear(); length = 0; peakData.clear();
}

void Audio::playMusic(float sec) {
    if (!ready || !musicLoaded) return;
    stopMusic();
    if (sec < 0) { delay = -sec; return; }
    if (sec >= length) return;
    if (d->sys->playSound(d->music, d->gMusic, true, &d->mch) != FMOD_OK) { d->mch = nullptr; return; }
    d->mch->setPosition((unsigned)(sec * 1000.f), FMOD_TIMEUNIT_MS);
    d->mch->setPaused(false);
}

void Audio::stopMusic() {
    delay = 0;
    if (d && d->mch) { d->mch->stop(); d->mch = nullptr; }
}

void Audio::pauseMusic(bool p) {
    if (d && d->mch) d->mch->setPaused(p);
}

bool Audio::musicPlaying() const {
    bool pl = false;
    if (d && d->mch && d->mch->isPlaying(&pl) == FMOD_OK) return pl;
    return false;
}

float Audio::musicPos() const {
    unsigned ms = 0;
    if (d && d->mch && d->mch->getPosition(&ms, FMOD_TIMEUNIT_MS) == FMOD_OK) return ms / 1000.f;
    return delay > 0 ? -delay : 0.f;
}

void Audio::playSfx(Sfx s) {
    if (!ready || !d->sfx[(int)s]) return;
    FMOD::Channel* ch = nullptr;
    d->sys->playSound(d->sfx[(int)s], d->gSfx, false, &ch);
}

#else  // ------------------------------------------------------------------ silent stub

struct Audio::Impl {};
Audio::Audio() : d(new Impl) {}
Audio::~Audio() { delete d; }
bool Audio::init() { return false; }
void Audio::shutdown() {}
void Audio::update(float) {}
bool Audio::loadMusic(const std::string&, std::string* err) { if (err) *err = "Built without FMOD (configure with -DCD_ENABLE_FMOD=ON)"; return false; }
void Audio::unloadMusic() {}
void Audio::playMusic(float) {}
void Audio::stopMusic() {}
void Audio::pauseMusic(bool) {}
bool Audio::musicPlaying() const { return false; }
float Audio::musicPos() const { return 0; }
void Audio::setVolumes(float, float, float) {}
void Audio::playSfx(Sfx) {}
void Audio::applyVolumes() {}

#endif

}  // namespace cd
