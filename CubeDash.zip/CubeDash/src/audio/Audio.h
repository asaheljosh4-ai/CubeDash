#pragma once
// FMOD Core based audio: streamed music import + procedurally generated SFX.
// If CD_HAS_FMOD is not defined the class compiles to a silent stub so the
// game still builds and runs without the FMOD SDK.
#include <string>
#include <vector>

namespace cd {

enum class Sfx { Jump, Death, Coin, Pad, Orb, Portal, Win, Flip, Click };

class Audio {
public:
    Audio();
    ~Audio();
    bool init();
    void shutdown();
    void update(float dt);  // call once per frame

    // music importer
    bool loadMusic(const std::string& path, std::string* err = nullptr);
    void unloadMusic();
    bool hasMusic() const { return musicLoaded; }
    const std::string& musicPath() const { return path; }
    float musicLength() const { return length; }          // seconds
    const std::vector<float>& peaks() const { return peakData; }  // 0..1 amplitude buckets

    // Start playing at `seconds` into the song. Negative values wait that long first.
    void playMusic(float seconds);
    void stopMusic();
    void pauseMusic(bool p);
    bool musicPlaying() const;
    float musicPos() const;  // seconds

    void setVolumes(float master, float music, float sfx);
    void playSfx(Sfx s);
    bool available() const { return ready; }

private:
    struct Impl;
    Impl* d = nullptr;
    bool ready = false, musicLoaded = false;
    std::string path;
    float length = 0, delay = 0;
    float vMaster = 1, vMusic = 1, vSfx = 1;
    std::vector<float> peakData;
    void applyVolumes();
};

}  // namespace cd
