#include <SDL.h>
#include <SDL_opengl.h>

#include <cstdio>
#include <filesystem>
#include <map>
#include <cmath>

#include "App.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_sdl2.h"
#include "imgui.h"

int main(int argc, char** argv) {
    bool dev = false;
    for (int i = 1; i < argc; i++) if (std::string(argv[i]) == "--dev") dev = true;
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) { std::fprintf(stderr, "SDL: %s\n", SDL_GetError()); return 1; }
#if defined(__ANDROID__)
    const char* glsl = "#version 300 es";
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
#elif defined(__APPLE__)
    const char* glsl = "#version 150";
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);
#else
    const char* glsl = "#version 130";
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
#endif
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_Window* win = SDL_CreateWindow("CubeDash", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 720,
                                       SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    if (!win) { std::fprintf(stderr, "Window: %s\n", SDL_GetError()); return 1; }
    SDL_GLContext gl = SDL_GL_CreateContext(win);
    SDL_GL_MakeCurrent(win, gl);
    SDL_GL_SetSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    char* bp = SDL_GetBasePath();
    std::string base = bp ? bp : "./";
    if (bp) SDL_free(bp);
    std::string font = base + "assets/font.ttf";
    if (std::filesystem::exists(font)) io.Fonts->AddFontFromFileTTF(font.c_str(), 18.f);
    ImGui_ImplSDL2_InitForOpenGL(win, gl);
    ImGui_ImplOpenGL3_Init(glsl);

    cd::App app;
    app.init(win, dev);

    // UI scale: phones render the whole UI at a virtual ~720p height.
    float ui = 1.f;
    std::map<SDL_FingerID, ImVec2> fingers;
    Uint64 prev = SDL_GetPerformanceCounter();
    while (!app.quit) {
        int w, h;
        SDL_GetWindowSize(win, &w, &h);
#if defined(__ANDROID__)
        ui = std::max(1.f, std::min(w, h) / 720.f);
#endif
        app.setUiScale(ui);
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            // scale pointer coordinates into UI space
            if (e.type == SDL_MOUSEMOTION) { e.motion.x = (Sint32)(e.motion.x / ui); e.motion.y = (Sint32)(e.motion.y / ui); }
            else if (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP) { e.button.x = (Sint32)(e.button.x / ui); e.button.y = (Sint32)(e.button.y / ui); }
            if (e.type == SDL_KEYDOWN || e.type == SDL_KEYUP) {
                if (e.key.keysym.sym == SDLK_AC_BACK) { io.AddKeyEvent(ImGuiKey_Escape, e.type == SDL_KEYDOWN); continue; }
            }
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) app.quit = true;
            else if (e.type == SDL_DROPFILE) { app.onDrop(e.drop.file); SDL_free(e.drop.file); }
            else if (e.type == SDL_FINGERDOWN || e.type == SDL_FINGERMOTION || e.type == SDL_FINGERUP) {
                ImVec2 old[2]; bool hadTwo = fingers.size() == 2;
                if (hadTwo) { int k = 0; for (auto& kv : fingers) old[k++] = kv.second; }
                if (e.type == SDL_FINGERUP) fingers.erase(e.tfinger.fingerId);
                else fingers[e.tfinger.fingerId] = ImVec2(e.tfinger.x * w / ui, e.tfinger.y * h / ui);
                app.onTouchCount((int)fingers.size());
                if (hadTwo && fingers.size() == 2 && e.type == SDL_FINGERMOTION) {
                    ImVec2 nw[2]; int k = 0; for (auto& kv : fingers) nw[k++] = kv.second;
                    auto dist = [](ImVec2 a, ImVec2 b) { return std::sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)); };
                    float d0 = dist(old[0], old[1]), d1 = dist(nw[0], nw[1]);
                    ImVec2 m0((old[0].x + old[1].x) / 2, (old[0].y + old[1].y) / 2), m1((nw[0].x + nw[1].x) / 2, (nw[0].y + nw[1].y) / 2);
                    app.onPinch(m1.x, m1.y, d0 > 1.f ? d1 / d0 : 1.f, m1.x - m0.x, m1.y - m0.y);
                }
            }
        }
        if (SDL_GetWindowFlags(win) & SDL_WINDOW_MINIMIZED) { SDL_Delay(50); continue; }
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        io.DisplaySize = ImVec2(io.DisplaySize.x / ui, io.DisplaySize.y / ui);
        io.DisplayFramebufferScale = ImVec2(io.DisplayFramebufferScale.x * ui, io.DisplayFramebufferScale.y * ui);
        Uint64 now = SDL_GetPerformanceCounter();
        float dt = (float)((double)(now - prev) / (double)SDL_GetPerformanceFrequency());
        prev = now;
        io.DeltaTime = std::max(1e-5f, std::min(dt, .1f));
        if (io.WantTextInput) SDL_StartTextInput(); else SDL_StopTextInput();
        ImGui::NewFrame();
        app.frame(dt);
        ImGui::Render();
        int dw, dh;
        SDL_GL_GetDrawableSize(win, &dw, &dh);
        glViewport(0, 0, dw, dh);
        glClearColor(0.05f, 0.07f, 0.15f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(win);
    }
    app.shutdown();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(gl);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
