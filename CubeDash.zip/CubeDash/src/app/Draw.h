#pragma once
// World / icon rendering through Dear ImGui's ImDrawList (hardware accelerated by the
// OpenGL3 backend). Pure drawing: no game state is modified here.
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include <vector>

#include "../core/Level.h"
#include "../core/Sim.h"
#include "imgui.h"

namespace cd {

struct View {
    float camX = -2.f, camY = -2.4f, S = 40.f;  // camera (world units), pixels per block
    ImVec2 origin{0, 0}, size{1, 1};             // viewport rectangle in screen pixels
    float X(float x) const { return origin.x + (x - camX) * S; }
    float Y(float y) const { return origin.y + size.y - (y - camY) * S; }
    float worldX(float px) const { return camX + (px - origin.x) / S; }
    float worldY(float py) const { return camY + (origin.y + size.y - py) / S; }
};

struct Particle {
    float x, y, vx, vy, life, maxLife, size, gravity;
    ImU32 color;
};

struct DrawOpts {
    bool grid = true, hitboxes = false, play = false, beatLines = false;
    float time = 0;
    int bg = 1;  // 0 off, 1 slow, 2 fast
    float bpm = 120, musicOffset = 0;
    int speed = 1;
};

ImU32 hsl(float h360, float s, float l, float a = 1.f);
float bgHue(float camX, int bg);
void setPalette(float hue);  // object fill / line colours follow the background hue

void drawBackground(ImDrawList* dl, const View& v, const DrawOpts& o);
void drawObject(ImDrawList* dl, char tag, ImVec2 topLeft, float S, float alpha, float time, float seed, bool collected = false);
void drawLevel(ImDrawList* dl, const Level& lv, const View& v, const DrawOpts& o, const Sim* sim,
               const std::vector<Particle>* parts, float alpha);
void drawFace(ImDrawList* dl, ImVec2 c, float r, int diff);
void drawModeIcon(ImDrawList* dl, char mode, ImVec2 c, float size);
void drawToolIcon(ImDrawList* dl, char tool, ImVec2 c, float size);  // palette icons ('m','e','X' or object tag)
void drawDevBadge(ImDrawList* dl, ImVec2 c, float size);

}  // namespace cd
