#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>

#include "App.h"

namespace fs = std::filesystem;

namespace cd {

namespace {
float frand() { return std::rand() / (float)RAND_MAX; }
}  // namespace

void App::burst(float x, float y, int n, std::vector<ImU32> cols, float spd, float life, float sz, float gr) {
    if (parts.size() > 500 || cols.empty()) return;
    for (int i = 0; i < n; i++) {
        float a = frand() * 6.2831853f, v = spd * (.3f + frand());
        parts.push_back({x, y, std::cos(a) * v, std::sin(a) * v, life * (.6f + frand() * .4f), life, sz * (.6f + frand() * .8f), gr, cols[i % cols.size()]});
    }
}

void App::playMusicAtSim() {
    if (audio.hasMusic()) audio.playMusic(playLevel.musicOffset + sim.t);
}

void App::startPlay(const Level& l, bool useStart, Screen ret) {
    playLevel = l;
    returnTo = ret;
    screen = Screen::Play;
    sim.setLevel(&playLevel);
    sim.practice = st.practice;
    sim.start(useStart);
    fromEditorStart = useStart;
    paused = false;
    prevHeld = true;  // a still-held mouse button from the menu click must not count as a jump
    endShown = false;
    deathT = winT = shake = flash = simAcc = 0;
    parts.clear();
    audio.stopMusic();
    if (playLevel.musicPath.empty()) audio.unloadMusic();
    else if (!(audio.hasMusic() && audio.musicPath() == playLevel.musicPath)) {
        std::string err;
        if (!fs::exists(playLevel.musicPath)) toast("Music file not found - playing without music");
        else if (!audio.loadMusic(playLevel.musicPath, &err)) toast("Music unavailable: " + err);
    }
    ImVec2 d = ImGui::GetIO().DisplaySize;
    const float S = std::min(d.y / 11.f, d.x / 9.f);
    playCamX = sim.P.x - d.x / S * .3f;
    playCamY = std::max(-1.5f, sim.P.y + .5f - d.y / S * .5f);
    playMusicAtSim();
}

void App::restartPlay() {
    int a = sim.attempt;
    sim.start(fromEditorStart);
    sim.attempt = a + 1;
    parts.clear();
    deathT = winT = 0;
    endShown = false;
    prevHeld = false;
    audio.stopMusic();
    playMusicAtSim();
}

void App::exitPlay() {
    audio.stopMusic();
    screen = returnTo;
    if (screen == Screen::Editor) previewing = false;
}

void App::handleEvents() {
    for (const Event& e : sim.events) {
        switch (e.type) {
            case Event::Jump:
                if (e.sub == 'L') burst(e.x, e.y, 3, {IM_COL32_WHITE}, 3.f, .3f, .1f, 8.f);
                else { audio.playSfx(Sfx::Jump); burst(e.x, e.y, 5, {IM_COL32_WHITE}, 3.f, .3f, .1f, 8.f); }
                break;
            case Event::Pad:
                audio.playSfx(Sfx::Pad);
                burst(e.x, e.y, 8, {e.sub == 'p' ? IM_COL32(255, 217, 59, 255) : IM_COL32(255, 79, 216, 255)}, 4.f, .35f, .12f, 0.f);
                break;
            case Event::Orb:
                audio.playSfx(Sfx::Orb);
                burst(e.x, e.y, 10, {e.sub == 'o' ? IM_COL32(255, 217, 59, 255) : IM_COL32(255, 79, 216, 255)}, 5.f, .4f, .12f, 0.f);
                break;
            case Event::Flip:
                audio.playSfx(Sfx::Flip);
                burst(e.x, e.y, 6, {IM_COL32(255, 158, 59, 255), IM_COL32_WHITE}, 4.f, .3f, .1f, 0.f);
                break;
            case Event::Portal: {
                audio.playSfx(Sfx::Portal);
                ImU32 c = e.sub == 'S' ? IM_COL32(255, 79, 216, 255) : e.sub == 'B' ? IM_COL32(255, 158, 59, 255)
                        : e.sub == 'W' ? IM_COL32(61, 245, 255, 255) : IM_COL32(125, 255, 79, 255);
                burst(e.x, e.y, 14, {c}, 5.f, .5f, .12f, 0.f);
                break;
            }
            case Event::Coin: {
                audio.playSfx(Sfx::Coin);
                burst(e.x, e.y, 14, {IM_COL32(255, 217, 59, 255), IM_COL32_WHITE}, 6.f, .5f, .12f, 0.f);
                toast("Secret coin! " + std::to_string(sim.coinsGot()) + "/" + std::to_string(sim.totalCoins));
                break;
            }
            case Event::Death: {
                audio.playSfx(Sfx::Death);
                audio.stopMusic();
                shake = .3f; flash = .4f;
                burst(e.x, e.y, 28, {IM_COL32(125, 255, 79, 255), IM_COL32(70, 201, 31, 255), IM_COL32_WHITE}, 9.f, .8f, .2f, 22.f);
                if (!sim.practice && !sim.startedFromMarker) {
                    int p = (int)std::floor(sim.progress() * 100.f);
                    int& b = bests[playLevel.name];
                    if (p > b) { b = p; saveBests(); }
                }
                break;
            }
            case Event::Win:
                audio.playSfx(Sfx::Win);
                burst(e.x, e.y, 60, {IM_COL32(255, 217, 59, 255), IM_COL32(125, 255, 79, 255), IM_COL32(79, 216, 255, 255), IM_COL32(255, 79, 216, 255), IM_COL32_WHITE}, 12.f, 1.6f, .2f, 14.f);
                if (!sim.practice && !sim.startedFromMarker) { bests[playLevel.name] = 100; saveBests(); }
                break;
        }
    }
    sim.events.clear();
}

void App::playFrame(float dt) {
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 disp = io.DisplaySize;
    const float S = std::min(disp.y / 11.f, disp.x / 9.f);
    ImDrawList* bg = ImGui::GetBackgroundDrawList();

    // ---- hotkeys
    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && !endShown) { paused = !paused; audio.pauseMusic(paused); }
    if (!paused && !io.WantTextInput) {
        if (ImGui::IsKeyPressed(ImGuiKey_R, false)) restartPlay();
        if (ImGui::IsKeyPressed(ImGuiKey_P, false)) {
            sim.practice = !sim.practice; st.practice = sim.practice; sim.cps.clear();
            toast(sim.practice ? "Practice mode on" : "Practice mode off");
        }
        if (ImGui::IsKeyPressed(ImGuiKey_H, false)) st.hitboxes = !st.hitboxes;
    }

    // ---- input edge detection
    const bool held = !paused && !endShown &&
                      (ImGui::IsKeyDown(ImGuiKey_Space) || ImGui::IsKeyDown(ImGuiKey_UpArrow) || ImGui::IsKeyDown(ImGuiKey_W) || (ImGui::IsMouseDown(0) && !io.WantCaptureMouse));
    if (held && !prevHeld) sim.press();
    if (!held && prevHeld) sim.release();
    prevHeld = held;

    // ---- simulation (fixed 240 Hz)
    if (!paused) {
        simAcc += std::min(dt, .05f);
        int n = 0;
        while (simAcc >= kDT && n++ < 40) {
            if (!sim.P.dead && !sim.won) sim.step();
            simAcc -= kDT;
        }
        if (simAcc > kDT) simAcc = 0;
        handleEvents();
        if (sim.P.dead) {
            deathT += dt;
            if (deathT > .7f) { deathT = 0; sim.respawn(); parts.clear(); prevHeld = false; playMusicAtSim(); }
        } else if (sim.won) {
            winT += dt;
            if (winT > .9f) endShown = true;
        }
        for (auto& p : parts) { p.vy -= p.gravity * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; }
        parts.erase(std::remove_if(parts.begin(), parts.end(), [](const Particle& p) { return p.life <= 0; }), parts.end());
        shake = std::max(0.f, shake - dt);
        flash = std::max(0.f, flash - dt * 1.5f);
    }
    const float alpha = (sim.P.dead || sim.won) ? 1.f : simAcc / kDT;

    // ---- camera
    const Player& P = sim.P;
    const float xi = P.px + (P.x - P.px) * alpha, yi = P.py + (P.y - P.py) * alpha;
    if (!P.dead) {
        playCamX = xi - disp.x / S * .3f;
        playCamY += (std::max(-1.5f, yi + .5f - disp.y / S * .5f) - playCamY) * (1.f - std::exp(-dt * 12.f));
    }
    View v;
    v.size = disp; v.S = S; v.camX = playCamX; v.camY = playCamY;
    if (shake > 0) { float k = S * .12f * shake; v.origin = ImVec2((frand() - .5f) * k * 2, (frand() - .5f) * k * 2); }
    DrawOpts o;
    o.play = true; o.hitboxes = st.hitboxes; o.time = time; o.bg = playLevel.bg;
    drawLevel(bg, playLevel, v, o, &sim, &parts, alpha);
    if (flash > 0) bg->AddRectFilled(ImVec2(0, 0), disp, IM_COL32(255, 255, 255, (int)(flash * 127)));

    // ---- HUD
    ImDrawList* fg = ImGui::GetForegroundDrawList();
    const float p = sim.progress();
    drawFace(fg, ImVec2(30, 26), 14.f, playLevel.diff);
    fg->AddRectFilled(ImVec2(disp.x * .2f, 14), ImVec2(disp.x * .8f, 22), IM_COL32(0, 0, 0, 150), 4);
    fg->AddRectFilled(ImVec2(disp.x * .2f, 14), ImVec2(disp.x * (.2f + .6f * p), 22), sim.practice ? IM_COL32(63, 232, 106, 255) : IM_COL32(125, 255, 79, 255), 4);
    char hud[160];
    int bestPct = bests.count(playLevel.name) ? bests[playLevel.name] : 0;
    std::snprintf(hud, sizeof hud, "%d%%   Attempt %d%s%s", (int)std::floor(p * 100), sim.attempt,
                  sim.totalCoins ? ("   Coins " + std::to_string(sim.coinsGot()) + "/" + std::to_string(sim.totalCoins)).c_str() : "",
                  sim.practice ? "   PRACTICE" : (bestPct ? ("   Best " + std::to_string(bestPct) + "%").c_str() : ""));
    ImFont* f = ImGui::GetFont();
    ImVec2 ts = f->CalcTextSizeA(16.f, 1e9f, 0.f, hud);
    fg->AddText(f, 16.f, ImVec2(disp.x / 2 - ts.x / 2 + 1, 30 + 1), IM_COL32(0, 0, 0, 160), hud);
    fg->AddText(f, 16.f, ImVec2(disp.x / 2 - ts.x / 2, 30), IM_COL32_WHITE, hud);
    if (sim.won && !endShown) {
        const char* t = "LEVEL COMPLETE";
        ImVec2 s2 = f->CalcTextSizeA(40.f, 1e9f, 0.f, t);
        fg->AddText(f, 40.f, ImVec2(disp.x / 2 - s2.x / 2 + 2, disp.y / 2 - s2.y / 2 + 2), IM_COL32(0, 0, 0, 180), t);
        fg->AddText(f, 40.f, ImVec2(disp.x / 2 - s2.x / 2, disp.y / 2 - s2.y / 2), IM_COL32(255, 217, 59, 255), t);
    }
    if (sim.startedFromMarker) fg->AddText(f, 13.f, ImVec2(12, disp.y - 24), IM_COL32(125, 255, 79, 220), "Started from Start Pos - progress not recorded");

    // ---- on-screen pause button (touch friendly)
    if (!paused && !endShown) {
        ImGui::SetNextWindowPos(ImVec2(disp.x - 10, 10), ImGuiCond_Always, ImVec2(1, 0));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
        ImGui::Begin("##pausebtn", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
        if (ImGui::Button("II", ImVec2(48, 48))) { paused = true; audio.pauseMusic(true); }
        ImGui::End();
        ImGui::PopStyleColor(2);
    }

    // ---- pause menu
    if (paused) {
        fg->AddRectFilled(ImVec2(0, 0), disp, IM_COL32(0, 0, 0, 130));
        ImGui::SetNextWindowPos(disp / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
        ImGui::SetNextWindowSize(ImVec2(300, 0));
        ImGui::Begin("Paused", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);
        const ImVec2 b(-1, 44);
        if (ImGui::Button("Resume", b)) { paused = false; audio.pauseMusic(false); prevHeld = true; }
        if (ImGui::Button("Restart", b)) { paused = false; audio.pauseMusic(false); restartPlay(); }
        if (ImGui::Checkbox("Practice mode", &sim.practice)) { st.practice = sim.practice; sim.cps.clear(); }
        ImGui::Checkbox("Show hitboxes", &st.hitboxes);
        if (ImGui::Button("Settings", b)) openSettings = true;
        if (ImGui::Button(returnTo == Screen::Editor ? "Back to editor" : "Exit level", b)) { paused = false; exitPlay(); }
        ImGui::End();
    }

    // ---- level complete
    if (endShown) {
        ImGui::SetNextWindowPos(disp / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
        ImGui::Begin("##end", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
        ImGui::SetWindowFontScale(1.6f);
        ImGui::TextColored(ImVec4(1, .85f, .23f, 1), "LEVEL COMPLETE");
        ImGui::SetWindowFontScale(1.f);
        ImGui::Text("%s  |  %d attempt%s%s", playLevel.name.c_str(), sim.attempt, sim.attempt > 1 ? "s" : "", sim.practice ? "  |  practice" : "");
        if (sim.totalCoins) ImGui::Text("Secret coins: %d / %d", sim.coinsGot(), sim.totalCoins);
        ImGui::Spacing();
        if (ImGui::Button("Retry", ImVec2(130, 42))) restartPlay();
        ImGui::SameLine();
        if (ImGui::Button(returnTo == Screen::Editor ? "Editor" : "Exit", ImVec2(130, 42))) exitPlay();
        ImGui::End();
    }
}

}  // namespace cd
