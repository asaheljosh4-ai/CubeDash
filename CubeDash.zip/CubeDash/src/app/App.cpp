#include "App.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>


namespace fs = std::filesystem;

namespace cd {

namespace {
ImU32 colA(int r, int g, int b, int a = 255) { return IM_COL32(r, g, b, a); }

void bigText(ImDrawList* dl, const char* t, ImVec2 center, float size, ImU32 col, bool shadow = true) {
    ImFont* f = ImGui::GetFont();
    ImVec2 ts = f->CalcTextSizeA(size, 1e9f, 0.f, t);
    ImVec2 p(center.x - ts.x / 2, center.y - ts.y / 2);
    if (shadow) dl->AddText(f, size, p + ImVec2(size * .05f, size * .06f), IM_COL32(0, 0, 0, 170), t);
    dl->AddText(f, size, p, col, t);
}

void touchScrollImpl(bool allowActive) {
    ImGuiIO& io = ImGui::GetIO();
    if ((allowActive || !ImGui::IsAnyItemActive()) && ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem) && ImGui::IsMouseDragging(0, 8.f))
        ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y);
}

bool endsWithI(const std::string& s, const char* suf) {
    std::string a = s, b = suf;
    std::transform(a.begin(), a.end(), a.begin(), ::tolower);
    return a.size() >= b.size() && a.compare(a.size() - b.size(), b.size(), b) == 0;
}
bool isAudioFile(const std::string& s) {
    for (const char* e : {".mp3", ".ogg", ".wav", ".flac", ".m4a", ".aac", ".opus", ".mod", ".xm", ".it", ".s3m"})
        if (endsWithI(s, e)) return true;
    return false;
}

void menuBackdrop(ImDrawList* dl, ImVec2 disp, float time, bool decor) {
    View v;
    v.size = disp;
    v.S = std::min(disp.y / 11.f, disp.x / 9.f);
    v.camX = time * 7.f;
    v.camY = -2.4f;
    DrawOpts o;
    o.bg = 2;
    o.time = time;
    drawBackground(dl, v, o);
    if (!decor) return;
    for (int x = (int)std::floor(v.camX) - 1; x <= v.camX + disp.x / v.S + 1; x++) {
        auto at = [&](char t, int y) { drawObject(dl, t, ImVec2(v.X((float)x), v.Y((float)y + 1)), v.S, 1.f, time, (float)x); };
        if (x % 11 == 5) at('s', 0);
        if (x % 17 == 9) { at('b', 0); at('b', 1); }
        if (x % 23 == 3) at('o', 2);
    }
    float ph = std::fmod(time, 1.5f) / 1.5f;
    float y = ph < .6f ? 4.2f * (ph / .6f) * (1.f - ph / .6f) : 0.f;
    drawModeIcon(dl, 'c', ImVec2(v.X(v.camX + 3.5f), v.Y(y + .5f)), v.S * 1.25f);
}
}  // namespace

void touchScroll(bool allowActive) { touchScrollImpl(allowActive); }

// ---------------------------------------------------------------- infrastructure
std::string App::slug(const std::string& n) const {
    std::string s;
    for (char c : n) s += std::isalnum((unsigned char)c) ? (char)std::tolower((unsigned char)c) : '_';
    if (s.empty()) s = "level";
    return s;
}

bool App::init(SDL_Window* window, bool devFlag) {
    win = window;
    char* pp = SDL_GetPrefPath("CubeDash", "CubeDash");
    prefDir = pp ? pp : "./";
    if (pp) SDL_free(pp);
    char* bp = SDL_GetBasePath();
    std::string base = bp ? bp : "./";
    if (bp) SDL_free(bp);
    officialDir = base + "levels/official";
    userDir = prefDir + "levels";
#ifdef __ANDROID__
    officialDir = prefDir + "official";
#endif
    std::error_code ec;
    fs::create_directories(userDir, ec);
    fs::create_directories(officialDir, ec);
    loadSettings();
    if (devFlag) st.dev = true;
    applyStyle();
    audio.init();
    applyAudio();
    loadBests();
    ensureOfficial();
    refreshLibrary();
    if (st.fullscreen) SDL_SetWindowFullscreen(win, SDL_WINDOW_FULLSCREEN_DESKTOP);
    return true;
}

void App::shutdown() {
    saveSettings();
    saveBests();
    audio.shutdown();
}

void App::applyStyle() {
    ImGuiStyle& s = ImGui::GetStyle();
    ImGui::StyleColorsDark();
    s.WindowRounding = 12; s.FrameRounding = 9; s.PopupRounding = 12; s.GrabRounding = 8; s.ScrollbarRounding = 9;
    s.FramePadding = ImVec2(10, 7); s.ItemSpacing = ImVec2(8, 8); s.WindowPadding = ImVec2(12, 12);
    s.WindowBorderSize = 1; s.FrameBorderSize = 0;
    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg] = ImVec4(.055f, .075f, .15f, .92f);
    c[ImGuiCol_PopupBg] = ImVec4(.06f, .08f, .17f, .98f);
    c[ImGuiCol_Border] = ImVec4(1, 1, 1, .10f);
    c[ImGuiCol_FrameBg] = ImVec4(1, 1, 1, .07f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(1, 1, 1, .12f);
    c[ImGuiCol_Button] = ImVec4(1, 1, 1, .08f);
    c[ImGuiCol_ButtonHovered] = ImVec4(.36f, .89f, 1.f, .28f);
    c[ImGuiCol_ButtonActive] = ImVec4(.36f, .89f, 1.f, .50f);
    c[ImGuiCol_SliderGrab] = ImVec4(.36f, .89f, 1.f, 1.f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(.6f, .95f, 1.f, 1.f);
    c[ImGuiCol_CheckMark] = ImVec4(.36f, .89f, 1.f, 1.f);
    c[ImGuiCol_Header] = ImVec4(.36f, .89f, 1.f, .22f);
    c[ImGuiCol_TitleBg] = ImVec4(.05f, .07f, .14f, 1);
    c[ImGuiCol_TitleBgActive] = ImVec4(.08f, .12f, .24f, 1);
}

void App::loadSettings() {
    std::ifstream f(prefDir + "settings.ini");
    std::string l;
    while (std::getline(f, l)) {
        auto eq = l.find('=');
        if (eq == std::string::npos) continue;
        std::string k = l.substr(0, eq);
        float v = (float)atof(l.c_str() + eq + 1);
        if (k == "master") st.master = v; else if (k == "music") st.music = v; else if (k == "sfx") st.sfx = v;
        else if (k == "hitboxes") st.hitboxes = v != 0; else if (k == "grid") st.grid = v != 0;
        else if (k == "practice") st.practice = v != 0; else if (k == "fullscreen") st.fullscreen = v != 0;
        else if (k == "dev") st.dev = v != 0;
    }
}
void App::saveSettings() {
    std::ofstream f(prefDir + "settings.ini");
    f << "master=" << st.master << "\nmusic=" << st.music << "\nsfx=" << st.sfx << "\nhitboxes=" << st.hitboxes
      << "\ngrid=" << st.grid << "\npractice=" << st.practice << "\nfullscreen=" << st.fullscreen << "\ndev=" << st.dev << "\n";
}
void App::loadBests() {
    std::ifstream f(prefDir + "bests.txt");
    std::string l;
    while (std::getline(f, l)) {
        auto t = l.find('\t');
        if (t != std::string::npos) bests[l.substr(t + 1)] = atoi(l.c_str());
    }
}
void App::saveBests() {
    std::ofstream f(prefDir + "bests.txt");
    for (auto& kv : bests) f << kv.second << '\t' << kv.first << '\n';
}

void App::ensureOfficial() {
    std::error_code ec;
    bool any = false;
    for (auto& e : fs::directory_iterator(officialDir, ec))
        if (e.path().extension() == ".cdl") any = true;
    if (any) return;
    saveLevel(makeDemoLevel(), officialDir + "/01_stereo_start.cdl");
    saveLevel(makeWaveLevel(), officialDir + "/02_zigzag_zone.cdl");
    saveLevel(makeBallLevel(), officialDir + "/03_gravity_flip.cdl");
}

void App::refreshLibrary() {
    auto scan = [](const std::string& dir, std::vector<LevelEntry>& out, bool forceOfficial) {
        out.clear();
        std::error_code ec;
        std::vector<std::string> files;
        for (auto& e : fs::directory_iterator(dir, ec))
            if (e.path().extension() == ".cdl") files.push_back(e.path().string());
        std::sort(files.begin(), files.end());
        for (auto& p : files) {
            LevelEntry le;
            le.path = p;
            if (loadLevel(le.lv, p)) {
                if (forceOfficial) le.lv.official = true;
                out.push_back(std::move(le));
            }
        }
    };
    scan(officialDir, mainLevels, true);
    scan(userDir, myLevels, false);
}

void App::drawToast(ImDrawList* dl, ImVec2 disp) {
    if (toastT <= 0) return;
    float a = std::min(1.f, toastT * 2.f);
    ImFont* f = ImGui::GetFont();
    ImVec2 ts = f->CalcTextSizeA(18.f, 1e9f, 0.f, toastMsg.c_str());
    ImVec2 c(disp.x / 2, 74.f);
    dl->AddRectFilled(c - ts / 2 - ImVec2(16, 9), c + ts / 2 + ImVec2(16, 9), IM_COL32(0, 0, 0, (int)(215 * a)), 16);
    dl->AddText(f, 18.f, c - ts / 2, IM_COL32(255, 255, 255, (int)(255 * a)), toastMsg.c_str());
}

void App::settingsPopup() {
    if (openSettings) { ImGui::OpenPopup("Settings"); openSettings = false; }
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(disp / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
    ImGui::SetNextWindowSize(ImVec2(std::min(440.f, disp.x - 20), 0));
    if (ImGui::BeginPopupModal("Settings", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize)) {
        bool ch = false;
        ch |= ImGui::SliderFloat("Master", &st.master, 0, 1, "%.2f");
        ch |= ImGui::SliderFloat("Music", &st.music, 0, 1, "%.2f");
        ch |= ImGui::SliderFloat("Effects", &st.sfx, 0, 1, "%.2f");
        if (ch) applyAudio();
        ImGui::Separator();
        ImGui::Checkbox("Show hitboxes in game", &st.hitboxes);
        ImGui::Checkbox("Editor grid", &st.grid);
        ImGui::Checkbox("Practice mode by default", &st.practice);
        if (ImGui::Checkbox("Fullscreen", &st.fullscreen)) SDL_SetWindowFullscreen(win, st.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
        if (ImGui::Checkbox("Developer mode (edit + publish main levels)", &st.dev)) toast(st.dev ? "Developer mode ON" : "Developer mode OFF");
        ImGui::TextDisabled("Audio engine: %s", audio.available() ? "FMOD ready" : "unavailable (silent)");
        ImGui::Spacing();
        if (ImGui::Button("Close", ImVec2(-1, 40))) { saveSettings(); ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
}

void App::onDrop(const std::string& path) {
    if (isAudioFile(path)) {
        if (screen == Screen::Editor) { musicInput = path; showMusic = true; loadMusicFor(path, true); }
        else toast("Open the editor first, then drop the song onto it");
    } else if (endsWithI(path, ".cdl")) {
        std::error_code ec;
        fs::copy_file(path, userDir + "/" + fs::path(path).filename().string(), fs::copy_options::overwrite_existing, ec);
        refreshLibrary();
        toast(ec ? "Import failed" : "Level imported to My Levels");
    }
}

void App::onTouchCount(int n) {
    touchCount = n;
    if (n < 2) { pinchActive = false; pinchZoom = 0; pinchDx = pinchDy = 0; }
}
void App::onPinch(float mx, float my, float s, float dx, float dy) {
    pinchX = mx; pinchY = my;
    pinchZoom = (pinchZoom == 0 ? 1.f : pinchZoom) * s;
    pinchDx += dx; pinchDy += dy;
    pinchActive = true;
}

// ---------------------------------------------------------------- frame dispatch
void App::frame(float dt) {
    time += dt;
    toastT = std::max(0.f, toastT - dt);
    audio.update(dt);
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    switch (screen) {
        case Screen::Menu: menuFrame(dt); break;
        case Screen::Select: selectFrame(); break;
        case Screen::Editor: editorFrame(dt); break;
        case Screen::Play: playFrame(dt); break;
    }
    settingsPopup();
    browserPopup();
    drawToast(ImGui::GetForegroundDrawList(), disp);
}

// ---------------------------------------------------------------- main menu
void App::menuFrame(float) {
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    ImDrawList* bg = ImGui::GetBackgroundDrawList();
    menuBackdrop(bg, disp, time, true);

    const float ts = std::min(disp.y * .15f, disp.x * .09f);
    bigText(bg, "CUBE", ImVec2(disp.x / 2 - ts * 1.55f, disp.y * .16f), ts, colA(125, 255, 79));
    bigText(bg, "DASH", ImVec2(disp.x / 2 + ts * 1.55f, disp.y * .16f), ts, colA(91, 227, 255));
    bigText(bg, "Build it. Play it. Make it yours.", ImVec2(disp.x / 2, disp.y * .16f + ts * .8f), std::max(15.f, ts * .22f), colA(255, 255, 255, 230), false);

    const ImVec2 bs(std::min(320.f, disp.x - 40), 56);
    ImGui::SetNextWindowPos(ImVec2(disp.x / 2, disp.y * .62f), ImGuiCond_Always, ImVec2(.5f, .5f));
    ImGui::SetNextWindowSize(ImVec2(bs.x + 24, 0));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    ImGui::SetWindowFontScale(1.35f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(.18f, .78f, .3f, .95f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(.3f, .9f, .42f, 1.f));
    if (ImGui::Button("PLAY", bs)) { audio.playSfx(Sfx::Click); refreshLibrary(); selectTab = 0; screen = Screen::Select; }
    ImGui::PopStyleColor(2);
    if (ImGui::Button("CREATE", bs)) { audio.playSfx(Sfx::Click); Level nl; nl.name = "My Level"; openEditor(nl, ""); }
    if (ImGui::Button("MY LEVELS", bs)) { audio.playSfx(Sfx::Click); refreshLibrary(); selectTab = 1; screen = Screen::Select; }
    if (ImGui::Button("SETTINGS", bs)) openSettings = true;
    if (ImGui::Button("QUIT", bs)) quit = true;
    ImGui::End();
    ImGui::PopStyleColor(2);

    // developer icon (bottom left): toggles dev mode
    ImGui::SetNextWindowPos(ImVec2(14, disp.y - 14), ImGuiCond_Always, ImVec2(0, 1));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::Begin("##dev", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
    ImVec2 p = ImGui::GetCursorScreenPos();
    if (ImGui::InvisibleButton("devbtn", ImVec2(56, 56))) { st.dev = !st.dev; saveSettings(); toast(st.dev ? "Developer mode ON - main levels are editable" : "Developer mode OFF"); }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (st.dev) dl->AddCircle(p + ImVec2(28, 28), 31, colA(255, 217, 59), 24, 3.f);
    drawDevBadge(dl, p + ImVec2(28, 28), st.dev ? 26.f : 22.f);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Developer mode: %s", st.dev ? "ON" : "OFF");
    ImGui::End();
    ImGui::PopStyleColor(2);

    bigText(bg, "v1.0", ImVec2(disp.x - 34, disp.y - 20), 14.f, colA(255, 255, 255, 160), false);
}

// ---------------------------------------------------------------- level select
void App::selectFrame() {
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    menuBackdrop(ImGui::GetBackgroundDrawList(), disp, time, false);
    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && !ImGui::IsPopupOpen("Delete level?")) screen = Screen::Menu;

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(disp);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, .25f));
    ImGui::Begin("##select", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);
    ImGui::PopStyleColor();
    touchScroll(true);

    if (ImGui::Button("< Back", ImVec2(96, 42))) screen = Screen::Menu;
    ImGui::SameLine();
    for (int t = 0; t < 2; t++) {
        bool on = selectTab == t;
        if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(.36f, .89f, 1.f, .75f));
        if (ImGui::Button(t == 0 ? "Main Levels" : "My Levels", ImVec2(140, 42))) selectTab = t;
        if (on) ImGui::PopStyleColor();
        ImGui::SameLine();
    }
    if (selectTab == 1) {
        if (ImGui::Button("New Level", ImVec2(120, 42))) { Level nl; nl.name = "My Level"; openEditor(nl, ""); }
        ImGui::SameLine();
        if (ImGui::Button("Import .cdl", ImVec2(120, 42))) {
            openBrowser("Import level (.cdl)", {".cdl"}, defaultBrowseDir(), [this](const std::string& f) { onDrop(f); });
        }
        ImGui::SameLine();
    }
    if (ImGui::Button("Refresh", ImVec2(90, 42))) refreshLibrary();
    ImGui::Spacing();

    static std::string pendingDelete;
    auto& list = selectTab == 0 ? mainLevels : myLevels;
    if (list.empty()) ImGui::TextDisabled(selectTab == 0 ? "No main levels found in levels/official" : "Nothing here yet - hit CREATE or import a .cdl file");
    int openIdx = -1, delIdx = -1, editIdx = -1;
    for (int i = 0; i < (int)list.size(); i++) {
        LevelEntry& e = list[i];
        ImGui::PushID(i);
        const bool canEdit = selectTab == 1 || st.dev;
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float w = ImGui::GetContentRegionAvail().x - 4, h = 84.f, btnW = canEdit ? 184.f : 0.f;
        const bool tapped = ImGui::InvisibleButton("##card", ImVec2(w - btnW - 8, h));
        const bool hov = ImGui::IsItemHovered();
        if (tapped && std::fabs(ImGui::GetMouseDragDelta(0).y) < 10.f) openIdx = i;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(p, p + ImVec2(w, h), hov ? colA(30, 44, 92, 245) : colA(18, 26, 58, 235), 16);
        dl->AddRect(p, p + ImVec2(w, h), hov ? colA(91, 227, 255, 200) : colA(255, 255, 255, 26), 16, 0, 1.5f);
        drawFace(dl, p + ImVec2(50, h / 2), 28.f, e.lv.diff);
        ImFont* f = ImGui::GetFont();
        dl->AddText(f, 26.f, p + ImVec2(96, 10), IM_COL32_WHITE, e.lv.name.c_str());
        float nameW = f->CalcTextSizeA(26.f, 1e9f, 0.f, e.lv.name.c_str()).x;
        if (e.lv.official) drawDevBadge(dl, p + ImVec2(96 + nameW + 22, 25), 13.f);
        static const char* dn[3] = {"Easy", "Normal", "Hard"};
        char sub[256];
        auto b = bests.find(e.lv.name);
        std::snprintf(sub, sizeof sub, "%s  |  by %s  |  %zu objects%s%s  |  %.0f BPM%s", dn[std::clamp(e.lv.diff, 0, 2)], e.lv.author.c_str(),
                      e.lv.obj.size(), e.lv.coins() ? "  |  secret coin" : "", "", e.lv.bpm, e.lv.musicPath.empty() ? "" : "  |  music");
        dl->AddText(f, 16.f, p + ImVec2(96, 44), IM_COL32(200, 215, 255, 220), sub);
        float pct = b == bests.end() ? 0.f : b->second / 100.f;
        dl->AddRectFilled(p + ImVec2(96, 66), p + ImVec2(96 + 220, 74), IM_COL32(0, 0, 0, 140), 4);
        dl->AddRectFilled(p + ImVec2(96, 66), p + ImVec2(96 + 220 * pct, 74), pct >= 1.f ? colA(255, 217, 59) : colA(125, 255, 79), 4);
        char bt[32];
        std::snprintf(bt, sizeof bt, "%d%%", b == bests.end() ? 0 : b->second);
        dl->AddText(f, 14.f, p + ImVec2(96 + 228, 62), IM_COL32(255, 255, 255, 200), bt);
        if (canEdit) {
            ImGui::SetCursorScreenPos(ImVec2(p.x + w - btnW, p.y + (h - 40) / 2));
            if (ImGui::Button("Edit", ImVec2(86, 40))) editIdx = i;
            ImGui::SameLine();
            if (ImGui::Button("Delete", ImVec2(86, 40))) delIdx = i;
        }
        ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + h));
        ImGui::Dummy(ImVec2(w, 8));
        ImGui::PopID();
    }
    if (delIdx >= 0) { pendingDelete = list[delIdx].path; ImGui::OpenPopup("Delete level?"); }
    ImGui::SetNextWindowPos(disp / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
    if (ImGui::BeginPopupModal("Delete level?", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Delete %s permanently?", fs::path(pendingDelete).filename().string().c_str());
        if (ImGui::Button("Delete", ImVec2(120, 38))) { std::error_code ec; fs::remove(pendingDelete, ec); refreshLibrary(); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(120, 38))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    ImGui::End();

    if (openIdx >= 0 && openIdx < (int)list.size()) { Level l = list[openIdx].lv; startPlay(l, false, Screen::Select); }
    else if (editIdx >= 0 && editIdx < (int)list.size()) { Level l = list[editIdx].lv; std::string path = list[editIdx].path; openEditor(l, path); }
}

}  // namespace cd
