#include "Draw.h"

#include <algorithm>
#include <cmath>

namespace cd {

namespace {
constexpr float PI = 3.14159265f;
ImU32 gDark = IM_COL32(12, 18, 40, 255), gLight = IM_COL32(120, 160, 255, 100);
const float kBgSpeed[3] = {0.f, 2.5f, 6.f};

ImU32 withAlpha(ImU32 c, float a) {
    ImVec4 f = ImGui::ColorConvertU32ToFloat4(c);
    f.w *= a;
    return ImGui::ColorConvertFloat4ToU32(f);
}
ImVec2 rot(ImVec2 c, float ang, float lx, float ly) {
    float co = std::cos(ang), si = std::sin(ang);
    return ImVec2(c.x + lx * co - ly * si, c.y + lx * si + ly * co);
}
void ellipse(ImDrawList* dl, ImVec2 c, float rx, float ry, ImU32 col, float th, bool fill) {
    constexpr int N = 32;
    ImVec2 p[N];
    for (int i = 0; i < N; i++) p[i] = ImVec2(c.x + std::cos(2 * PI * i / N) * rx, c.y + std::sin(2 * PI * i / N) * ry);
    if (fill) dl->AddConvexPolyFilled(p, N, col);
    else dl->AddPolyline(p, N, col, ImDrawFlags_Closed, th);
}
// Rotated rectangle given in local units of `u` pixels around centre c.
void rrect(ImDrawList* dl, ImVec2 c, float ang, float u, float x0, float y0, float x1, float y1, ImU32 fill, ImU32 stroke = 0, float th = 1.f) {
    ImVec2 p[4] = {rot(c, ang, x0 * u, y0 * u), rot(c, ang, x1 * u, y0 * u), rot(c, ang, x1 * u, y1 * u), rot(c, ang, x0 * u, y1 * u)};
    if (fill) dl->AddConvexPolyFilled(p, 4, fill);
    if (stroke) dl->AddPolyline(p, 4, stroke, ImDrawFlags_Closed, th);
}
void cubeAt(ImDrawList* dl, ImVec2 c, float ang, float S, float size, float ox, float oy) {
    // `size` in blocks, offset (ox,oy) in blocks, both relative to the rotated frame.
    ImVec2 cc = rot(c, ang, ox * S, oy * S);
    float u = S * size;
    rrect(dl, cc, ang, u, -.5f, -.5f, .5f, .5f, IM_COL32(125, 255, 79, 255));
    rrect(dl, cc, ang, u, -.33f, -.33f, .33f, .33f, IM_COL32(70, 201, 31, 255));
    rrect(dl, cc, ang, u, -.5f, -.5f, .5f, .5f, 0, IM_COL32(0, 0, 0, 255), std::max(1.5f, u * .05f));
    rrect(dl, cc, ang, u, -.3f, -.25f, -.1f, -.05f, IM_COL32(0, 0, 0, 255));
    rrect(dl, cc, ang, u, .1f, -.25f, .3f, -.05f, IM_COL32(0, 0, 0, 255));
    rrect(dl, cc, ang, u, -.3f, .15f, .3f, .27f, IM_COL32(0, 0, 0, 255));
}
void tri(ImDrawList* dl, ImVec2 a, ImVec2 b, ImVec2 c, ImU32 fill, ImU32 stroke, float th) {
    dl->AddTriangleFilled(a, b, c, fill);
    dl->AddTriangle(a, b, c, stroke, th);
}
void sky(ImDrawList* dl, const View& v, float par, ImU32 col, float sz, double seed) {
    const float u = v.S * sz, sh = v.camX * v.S * par;
    const int i0 = (int)std::floor(sh / u) - 1, n = (int)std::ceil(v.size.x / u) + 3;
    const float gy = v.Y(0);
    for (int i = i0; i < i0 + n; i++) {
        double f = std::sin(i * 12.9898 + seed) * 43758.5453;
        float r = (float)std::fabs(f - std::floor(f));
        float hh = (r * .5f + .2f) * v.size.y * .55f;
        float x = v.origin.x + i * u - sh;
        dl->AddRectFilled(ImVec2(x, gy - hh), ImVec2(x + u * .85f, gy + 2), col);
    }
}
}  // namespace

ImU32 hsl(float h, float s, float l, float a) {
    h = std::fmod(h, 360.f);
    if (h < 0) h += 360.f;
    float v = l + s * std::min(l, 1 - l);
    float sv = v <= 0 ? 0 : 2 * (1 - l / v);
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(h / 360.f, sv, v, r, g, b);
    return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, a));
}

float bgHue(float camX, int bg) { return std::fmod(std::fmod(215.f + camX * kBgSpeed[std::clamp(bg, 0, 2)], 360.f) + 360.f, 360.f); }

void setPalette(float hue) {
    gDark = hsl(hue, .5f, .11f);
    gLight = hsl(hue, .85f, .72f, .4f);
}

void drawBackground(ImDrawList* dl, const View& v, const DrawOpts& o) {
    const float hue = bgHue(v.camX, o.bg);
    setPalette(hue);
    ImVec2 a = v.origin, b = v.origin + v.size;
    dl->AddRectFilledMultiColor(a, b, hsl(hue, .7f, .26f), hsl(hue, .7f, .26f), hsl(hue, .75f, .5f), hsl(hue, .75f, .5f));
    if (o.bg) {
        sky(dl, v, .05f * o.bg, hsl(hue, .6f, .24f, .5f), 2.4f, 1.0);
        sky(dl, v, .10f * o.bg, hsl(hue, .55f, .17f, .6f), 1.5f, 7.0);
    }
    const float gy = v.Y(0);
    dl->PushClipRect(a, b, true);
    dl->AddRectFilled(ImVec2(a.x, gy), ImVec2(b.x, b.y + 20), hsl(hue, .6f, .14f));
    for (int x = (int)std::floor(v.camX); x <= v.camX + v.size.x / v.S + 1; x++)
        dl->AddLine(ImVec2(v.X((float)x), gy), ImVec2(v.X((float)x), b.y), IM_COL32(255, 255, 255, 18));
    dl->AddRectFilled(ImVec2(a.x, gy - 1), ImVec2(b.x, gy + 2), IM_COL32_WHITE);
    dl->PopClipRect();
}

void drawObject(ImDrawList* dl, char tag, ImVec2 tl, float S, float alpha, float time, float seed, bool collected) {
    const float c = S * .5f, lw = std::max(1.5f, S * .05f);
    const ImU32 dark = withAlpha(gDark, alpha), white = withAlpha(IM_COL32_WHITE, alpha), light = withAlpha(gLight, alpha);
    const ImVec2 mid = tl + ImVec2(c, c);
    auto spike = [&](float sc, bool down) {
        if (down) tri(dl, tl, ImVec2(tl.x + c, tl.y + S * .92f), ImVec2(tl.x + S, tl.y), dark, white, lw);
        else {
            float w = S * sc, x0 = tl.x + (S - w) / 2;
            tri(dl, ImVec2(x0, tl.y + S), ImVec2(x0 + w / 2, tl.y + S - S * sc * .92f), ImVec2(x0 + w, tl.y + S), dark, white, lw);
        }
    };
    switch (tag) {
        case 'b':
            dl->AddRectFilled(tl, tl + ImVec2(S, S), dark);
            dl->AddRect(tl + ImVec2(1, 1), tl + ImVec2(S - 1, S - 1), white, 0, 0, lw);
            dl->AddRect(tl + ImVec2(S * .16f, S * .16f), tl + ImVec2(S * .84f, S * .84f), light);
            break;
        case 'l':
            dl->AddRectFilled(tl + ImVec2(0, c), tl + ImVec2(S, S), dark);
            dl->AddRect(tl + ImVec2(1, c + 1), tl + ImVec2(S - 1, S - 1), white, 0, 0, lw);
            dl->AddRect(tl + ImVec2(S * .12f, c + S * .1f), tl + ImVec2(S * .88f, S - S * .1f), light);
            break;
        case 's': spike(1.f, false); break;
        case 'n': spike(.5f, false); break;
        case 'd': spike(1.f, true); break;
        case 'w': {
            const float a0 = time * 7.f;
            ImVec2 p[16];
            for (int i = 0; i < 16; i++) {
                float r = (i % 2) ? S * .28f : S * .48f, a = a0 + i * PI / 8;
                p[i] = ImVec2(mid.x + std::cos(a) * r, mid.y + std::sin(a) * r);
            }
            for (int i = 0; i < 16; i++) dl->AddTriangleFilled(mid, p[i], p[(i + 1) % 16], dark);
            dl->AddPolyline(p, 16, white, ImDrawFlags_Closed, lw);
            dl->AddCircle(mid, S * .12f, white, 16, lw);
            break;
        }
        case 'p': case 'k': {
            ImU32 col = tag == 'p' ? IM_COL32(255, 217, 59, 255) : IM_COL32(255, 79, 216, 255);
            dl->AddRectFilled(tl + ImVec2(S * .1f, S * .75f), tl + ImVec2(S * .9f, S), withAlpha(col, alpha));
            dl->AddRectFilled(tl + ImVec2(S * .2f, S * .55f), tl + ImVec2(S * .8f, S * .75f), withAlpha(col, alpha * .35f));
            break;
        }
        case 'o': case 'q': {
            ImU32 col = tag == 'o' ? IM_COL32(255, 217, 59, 255) : IM_COL32(255, 79, 216, 255);
            float pu = std::sin(time * 5.f) * S * .03f;
            dl->AddCircleFilled(mid, S * .36f + pu, withAlpha(col, alpha * .53f), 24);
            dl->AddCircle(mid, S * .36f + pu, withAlpha(col, alpha), 24, 3.f * S / 40.f + 1.f);
            dl->AddCircle(mid, S * .5f + pu * 2, withAlpha(col, alpha * .35f), 24, 2.f);
            break;
        }
        case 'C': case 'S': case 'B': case 'W': {
            ImU32 col = tag == 'S' ? IM_COL32(255, 79, 216, 255) : tag == 'C' ? IM_COL32(125, 255, 79, 255)
                      : tag == 'B' ? IM_COL32(255, 158, 59, 255) : IM_COL32(61, 245, 255, 255);
            ellipse(dl, mid, S * .3f, S * 1.45f, withAlpha(col, alpha * .25f), 0, true);
            ellipse(dl, mid, S * .3f, S * 1.45f, withAlpha(col, alpha), 5.f * S / 40.f + 1.f, false);
            break;
        }
        case 'c':
            if (!collected) {
                float a = time * 2.4f + seed * .7f, w = std::fabs(std::cos(a)) * S * .8f, h = S * .94f * .8f + S * .1f;
                float e = S * .08f * std::fabs(std::sin(a));
                ImVec2 a0 = mid + ImVec2(-(w / 2 + e), -h / 2), a1 = mid + ImVec2(w / 2 + e, h / 2);
                dl->AddRectFilled(a0, a1, withAlpha(IM_COL32(184, 106, 0, 255), alpha), std::min((a1.x - a0.x) / 2, S * .1f));
                dl->AddRect(a0, a1, withAlpha(IM_COL32_BLACK, alpha), S * .1f, 0, 1.5f);
                if (w > 2) {
                    dl->AddRectFilled(mid + ImVec2(-w / 2, -S * .36f), mid + ImVec2(w / 2, S * .36f), withAlpha(IM_COL32(255, 205, 40, 255), alpha), S * .1f);
                    float iw = w * .55f;
                    dl->AddRect(mid + ImVec2(-iw / 2, -S * .22f), mid + ImVec2(iw / 2, S * .22f), withAlpha(IM_COL32(255, 245, 160, 255), alpha), S * .06f, 0, 1.5f);
                }
            }
            break;
        default: break;
    }
}

void drawFace(ImDrawList* dl, ImVec2 c, float r, int d) {
    static const ImU32 col[3] = {IM_COL32(79, 216, 255, 255), IM_COL32(107, 220, 74, 255), IM_COL32(255, 217, 59, 255)};
    static const ImU32 edge[3] = {IM_COL32(28, 143, 181, 255), IM_COL32(47, 154, 28, 255), IM_COL32(201, 143, 0, 255)};
    d = std::clamp(d, 0, 2);
    const float lw = std::max(1.4f, r * .11f);
    const ImU32 black = IM_COL32_BLACK;
    dl->AddCircleFilled(c, r, edge[d], 32);
    dl->AddCircleFilled(c + ImVec2(-r * .12f, -r * .14f), r * .86f, col[d], 32);
    dl->AddCircle(c, r, black, 32, lw);
    const float ey = -r * .12f, ex = r * .38f, rx = r * .2f, ry = r * (d == 2 ? .17f : .26f);
    for (int s = -1; s <= 1; s += 2) {
        ImVec2 e = c + ImVec2(s * ex, ey);
        ellipse(dl, e, rx, ry, IM_COL32_WHITE, 0, true);
        ellipse(dl, e, rx, ry, black, lw, false);
        dl->AddCircleFilled(e + ImVec2(-s * r * .02f, r * .04f), r * (d == 2 ? .09f : .11f), black, 12);
        if (d == 0) {
            dl->AddCircleFilled(c + ImVec2(s * r * .62f, r * .28f), r * .13f, IM_COL32(255, 90, 140, 90), 12);
            dl->AddBezierQuadratic(e + ImVec2(-rx, -r * .42f), e + ImVec2(0, -r * .7f), e + ImVec2(rx, -r * .42f), black, lw);
        } else {
            float k = d == 1 ? r * .03f : r * .17f;
            dl->AddLine(e + ImVec2(s * r * .26f, -r * .4f - k + 0), e + ImVec2(-s * r * .26f, -r * .4f + k), black, lw * (d == 2 ? 1.5f : 1.f));
        }
    }
    if (d == 0) {
        dl->AddBezierQuadratic(c + ImVec2(-r * .42f, r * .2f), c + ImVec2(0, r * 1.0f), c + ImVec2(r * .42f, r * .2f), black, lw);
        dl->AddLine(c + ImVec2(-r * .42f, r * .2f), c + ImVec2(r * .42f, r * .2f), black, lw);
    } else if (d == 1) {
        dl->AddBezierQuadratic(c + ImVec2(-r * .4f, r * .28f), c + ImVec2(0, r * .7f), c + ImVec2(r * .4f, r * .28f), black, lw);
    } else {
        dl->AddBezierQuadratic(c + ImVec2(-r * .38f, r * .52f), c + ImVec2(0, r * .52f), c + ImVec2(r * .4f, r * .3f), black, lw);
    }
}

void drawDevBadge(ImDrawList* dl, ImVec2 c, float s) {
    // wrench-in-hexagon "DEV" emblem
    ImVec2 p[6];
    for (int i = 0; i < 6; i++) p[i] = ImVec2(c.x + std::cos(PI / 6 + i * PI / 3) * s, c.y + std::sin(PI / 6 + i * PI / 3) * s);
    dl->AddConvexPolyFilled(p, 6, IM_COL32(255, 111, 60, 255));
    dl->AddPolyline(p, 6, IM_COL32_BLACK, ImDrawFlags_Closed, std::max(1.5f, s * .1f));
    ImFont* f = ImGui::GetFont();
    float fs = s * .78f;
    const char* t = "DEV";
    ImVec2 ts = f->CalcTextSizeA(fs, 1e9f, 0.f, t);
    dl->AddText(f, fs, ImVec2(c.x - ts.x / 2, c.y - ts.y / 2), IM_COL32_WHITE, t);
}

void drawModeIcon(ImDrawList* dl, char mode, ImVec2 c, float s) {
    switch (mode) {
        case 's': {
            ImVec2 p[5] = {c + ImVec2(-s * .5f, s * .1f), c + ImVec2(-s * .3f, -s * .15f), c + ImVec2(s * .3f, -s * .15f), c + ImVec2(s * .55f, s * .05f), c + ImVec2(s * .3f, s * .3f)};
            dl->AddConvexPolyFilled(p, 5, IM_COL32(255, 79, 216, 255));
            dl->AddPolyline(p, 5, IM_COL32_BLACK, ImDrawFlags_Closed, 1.5f);
            break;
        }
        case 'b':
            dl->AddCircleFilled(c, s * .45f, IM_COL32(255, 158, 59, 255), 20);
            dl->AddCircle(c, s * .45f, IM_COL32_BLACK, 20, 1.5f);
            dl->AddLine(c + ImVec2(-s * .45f, 0), c + ImVec2(s * .45f, 0), IM_COL32_BLACK, 1.5f);
            dl->AddLine(c + ImVec2(0, -s * .45f), c + ImVec2(0, s * .45f), IM_COL32_BLACK, 1.5f);
            break;
        case 'w':
            dl->AddTriangleFilled(c + ImVec2(s * .5f, 0), c + ImVec2(-s * .45f, -s * .4f), c + ImVec2(-s * .15f, 0), IM_COL32(61, 245, 255, 255));
            dl->AddTriangleFilled(c + ImVec2(s * .5f, 0), c + ImVec2(-s * .15f, 0), c + ImVec2(-s * .45f, s * .4f), IM_COL32(40, 190, 220, 255));
            break;
        default: cubeAt(dl, c, 0, s, .8f, 0, 0); break;
    }
}

void drawToolIcon(ImDrawList* dl, char tool, ImVec2 c, float s) {
    const ImU32 white = IM_COL32(235, 240, 255, 255);
    ImU32 sd = gDark, sl = gLight;
    gDark = IM_COL32(27, 33, 80, 255);
    gLight = IM_COL32(150, 170, 255, 120);
    const ImVec2 tl = c - ImVec2(s / 2, s / 2);
    switch (tool) {
        case 'm':
            for (int i = 0; i < 4; i++) {
                float a = i * PI / 2;
                ImVec2 e = c + ImVec2(std::cos(a), std::sin(a)) * s * .42f;
                dl->AddLine(c, e, white, 2.f);
                dl->AddTriangleFilled(e + ImVec2(std::cos(a), std::sin(a)) * s * .1f,
                                      e + ImVec2(-std::sin(a), std::cos(a)) * s * .12f - ImVec2(std::cos(a), std::sin(a)) * s * .06f,
                                      e - ImVec2(-std::sin(a), std::cos(a)) * s * .12f - ImVec2(std::cos(a), std::sin(a)) * s * .06f, white);
            }
            break;
        case 'e': {
            ImVec2 p[4] = {c + ImVec2(-s * .42f, s * .1f), c + ImVec2(s * .05f, -s * .4f), c + ImVec2(s * .42f, -s * .02f), c + ImVec2(-s * .05f, s * .42f)};
            dl->AddConvexPolyFilled(p, 4, IM_COL32(255, 138, 138, 110));
            dl->AddPolyline(p, 4, white, ImDrawFlags_Closed, 2.f);
            dl->AddLine(c + ImVec2(-s * .2f, -s * .12f), c + ImVec2(s * .2f, s * .3f), white, 2.f);
            break;
        }
        case 'X': {
            dl->AddRectFilled(tl + ImVec2(s * .1f, s * .1f), tl + ImVec2(s * .9f, s * .9f), IM_COL32(125, 255, 79, 70));
            dl->AddRect(tl + ImVec2(s * .1f, s * .1f), tl + ImVec2(s * .9f, s * .9f), IM_COL32(125, 255, 79, 255), 0, 0, 2.f);
            dl->AddTriangleFilled(c + ImVec2(-s * .15f, -s * .25f), c + ImVec2(-s * .15f, s * .25f), c + ImVec2(s * .28f, 0), IM_COL32(125, 255, 79, 255));
            break;
        }
        case 'C': case 'S': case 'B': case 'W': {
            ImU32 col = tool == 'S' ? IM_COL32(255, 79, 216, 255) : tool == 'C' ? IM_COL32(125, 255, 79, 255)
                      : tool == 'B' ? IM_COL32(255, 158, 59, 255) : IM_COL32(61, 245, 255, 255);
            ellipse(dl, c, s * .24f, s * .44f, withAlpha(col, .25f), 0, true);
            ellipse(dl, c, s * .24f, s * .44f, col, 3.f, false);
            break;
        }
        case 'c': drawObject(dl, 'c', tl, s, 1.f, 0.f, 0.f); break;
        case 'w': drawObject(dl, 'w', tl, s, 1.f, 0.f, 0.f); break;
        default: drawObject(dl, tool, tl, s, 1.f, 0.f, 0.f); break;
    }
    gDark = sd;
    gLight = sl;
}

void drawLevel(ImDrawList* dl, const Level& lv, const View& v, const DrawOpts& o, const Sim* sim,
               const std::vector<Particle>* parts, float alpha) {
    drawBackground(dl, v, o);
    dl->PushClipRect(v.origin, v.origin + v.size, true);
    const float S = v.S, gy = v.Y(0);
    const float x0 = std::floor(v.camX) - 1, x1 = std::ceil(v.camX + v.size.x / S) + 1;
    const bool play = o.play && sim;

    if (!play) {
        if (o.grid) {
            for (int x = (int)x0; x <= x1; x++) dl->AddLine(ImVec2(v.X((float)x), v.origin.y), ImVec2(v.X((float)x), v.origin.y + v.size.y), IM_COL32(255, 255, 255, 32));
            for (int y = (int)std::floor(v.camY); y <= v.camY + v.size.y / S + 1; y++) dl->AddLine(ImVec2(v.origin.x, v.Y((float)y)), ImVec2(v.origin.x + v.size.x, v.Y((float)y)), IM_COL32(255, 255, 255, 32));
            for (int x = (int)std::ceil(x0 / 5) * 5; x <= x1; x += 5) dl->AddLine(ImVec2(v.X((float)x), v.origin.y), ImVec2(v.X((float)x), v.origin.y + v.size.y), IM_COL32(255, 255, 255, 64));
        }
        if (o.beatLines && o.bpm > 1) {
            const float spb = 60.f / o.bpm, sp = kSpeed[std::clamp(o.speed, 0, kSpeedCount - 1)];
            int n0 = (int)std::floor((x0 / sp + o.musicOffset) / spb), n1 = (int)std::ceil((x1 / sp + o.musicOffset) / spb);
            for (int n = std::max(0, n0); n <= n1; n++) {
                float wx = sp * (n * spb - o.musicOffset);
                bool bar = n % 4 == 0;
                dl->AddLine(ImVec2(v.X(wx), v.origin.y), ImVec2(v.X(wx), v.origin.y + v.size.y), bar ? IM_COL32(255, 217, 59, 150) : IM_COL32(255, 217, 59, 60), bar ? 2.f : 1.f);
            }
        }
        if (!lv.hasStart) {  // default spawn ghost
            dl->AddRectFilled(ImVec2(v.X(0), v.Y(1)), ImVec2(v.X(1), v.Y(0)), IM_COL32(125, 255, 79, 85));
            dl->AddRect(ImVec2(v.X(0), v.Y(1)), ImVec2(v.X(1), v.Y(0)), IM_COL32(125, 255, 79, 255));
        }
    } else if (sim->P.m != Mode::Cube) {
        const float cy = v.Y(kCeil + 1);
        dl->AddRectFilled(ImVec2(v.origin.x, v.origin.y - 20), ImVec2(v.origin.x + v.size.x, cy), hsl(bgHue(v.camX, o.bg), .6f, .14f));
        dl->AddRectFilled(ImVec2(v.origin.x, cy - 3), ImVec2(v.origin.x + v.size.x, cy), IM_COL32_WHITE);
    }
    (void)gy;

    // objects
    for (int x = (int)x0; x <= x1; x++)
        for (int y = 0; y <= kMaxY; y++) {
            char t = lv.get(x, y);
            if (!t) continue;
            ImVec2 tl(v.X((float)x), v.Y((float)y + 1));
            if (tl.y < v.origin.y - 2 * S || tl.y > v.origin.y + v.size.y + 2 * S) continue;
            bool col = play && t == 'c' && sim->got.count(cellKey(x, y));
            drawObject(dl, t, tl, S, 1.f, o.time, (float)x, col);
        }
    // start-position marker
    if (!play && lv.hasStart) {
        ImVec2 a(v.X((float)lv.startX), v.Y((float)lv.startY + 1)), b(v.X((float)lv.startX + 1), v.Y((float)lv.startY));
        dl->AddRectFilled(a, b, IM_COL32(125, 255, 79, 70));
        dl->AddRect(a, b, IM_COL32(125, 255, 79, 255), 0, 0, 2.f);
        dl->AddTriangleFilled(ImVec2(a.x + S * .3f, a.y + S * .22f), ImVec2(a.x + S * .3f, a.y + S * .78f), ImVec2(a.x + S * .78f, a.y + S * .5f), IM_COL32(125, 255, 79, 255));
        dl->AddText(ImGui::GetFont(), std::max(10.f, S * .28f), ImVec2(a.x, a.y - S * .34f), IM_COL32(125, 255, 79, 255), "START");
        drawModeIcon(dl, lv.startMode, ImVec2(a.x + S * .78f, a.y + S * .2f), S * .3f);
    }

    if (play) {
        const Player& P = sim->P;
        if (sim->practice)
            for (auto& c : sim->cps) {
                ImVec2 m(v.X(c.x + .5f), v.Y(c.y + 1.4f));
                float r = S * .2f;
                ImVec2 p[4] = {m + ImVec2(0, -r), m + ImVec2(r, 0), m + ImVec2(0, r), m + ImVec2(-r, 0)};
                dl->AddConvexPolyFilled(p, 4, IM_COL32(63, 232, 106, 255));
                dl->AddPolyline(p, 4, IM_COL32_BLACK, ImDrawFlags_Closed, 1.5f);
            }
        const float xi = P.px + (P.x - P.px) * alpha, yi = P.py + (P.y - P.py) * alpha, ri = P.pr + (P.rot - P.pr) * alpha;
        if (!P.dead && P.trail.size() > 1) {
            const bool wave = P.m == Mode::Wave;
            for (size_t i = 1; i < P.trail.size(); i++) {
                float a = (float)i / P.trail.size();
                dl->AddLine(ImVec2(v.X(P.trail[i - 1].first), v.Y(P.trail[i - 1].second)), ImVec2(v.X(P.trail[i].first), v.Y(P.trail[i].second)),
                            wave ? IM_COL32(61, 245, 255, (int)(a * 230)) : IM_COL32(61, 245, 255, (int)(a * 200)), S * (wave ? .22f : .3f) * a);
            }
        }
        if (!P.dead) {
            ImVec2 c(v.X(xi + .5f), v.Y(yi + .5f));
            float ang = ri * PI / 180.f;
            switch (P.m) {
                case Mode::Cube: cubeAt(dl, c, ang, S, 1.f, 0, 0); break;
                case Mode::Ship: {
                    ImVec2 body[6] = {rot(c, ang, -S * .78f, S * .06f), rot(c, ang, -S * .55f, -S * .1f), rot(c, ang, S * .35f, -S * .12f),
                                      rot(c, ang, S * .8f, S * .04f), rot(c, ang, S * .55f, S * .28f), rot(c, ang, -S * .5f, S * .3f)};
                    dl->AddConvexPolyFilled(body, 6, IM_COL32(255, 79, 216, 255));
                    dl->AddPolyline(body, 6, IM_COL32_BLACK, ImDrawFlags_Closed, 2.f);
                    ImVec2 fin[3] = {rot(c, ang, -S * .78f, -S * .3f), rot(c, ang, -S * .4f, -S * .1f), rot(c, ang, -S * .78f, S * .06f)};
                    dl->AddConvexPolyFilled(fin, 3, IM_COL32(200, 50, 170, 255));
                    dl->AddPolyline(fin, 3, IM_COL32_BLACK, ImDrawFlags_Closed, 2.f);
                    cubeAt(dl, c, ang, S, .5f, .1f, -.4f);
                    break;
                }
                case Mode::Ball: {
                    dl->AddCircleFilled(c, S * .5f, IM_COL32(255, 158, 59, 255), 32);
                    dl->AddCircleFilled(c, S * .32f, IM_COL32(210, 110, 20, 255), 24);
                    for (int i = 0; i < 4; i++) {
                        float a = ang + i * PI / 2;
                        dl->AddLine(c + ImVec2(std::cos(a), std::sin(a)) * S * .12f, c + ImVec2(std::cos(a), std::sin(a)) * S * .5f, IM_COL32_BLACK, 2.f);
                    }
                    dl->AddCircle(c, S * .5f, IM_COL32_BLACK, 32, 2.f);
                    break;
                }
                case Mode::Wave: {
                    ImVec2 tip = rot(c, ang, S * .55f, 0), t1 = rot(c, ang, -S * .45f, -S * .4f), mdl = rot(c, ang, -S * .15f, 0), t2 = rot(c, ang, -S * .45f, S * .4f);
                    dl->AddTriangleFilled(tip, t1, mdl, IM_COL32(61, 245, 255, 255));
                    dl->AddTriangleFilled(tip, mdl, t2, IM_COL32(35, 180, 215, 255));
                    ImVec2 o4[4] = {tip, t1, mdl, t2};
                    dl->AddPolyline(o4, 4, IM_COL32_BLACK, ImDrawFlags_Closed, 2.f);
                    break;
                }
            }
        }
        if (o.hitboxes) {
            const ImU32 red = IM_COL32(255, 59, 59, 255);
            for (int x = (int)x0; x <= x1; x++)
                for (int y = 0; y <= kMaxY; y++) {
                    char t = lv.get(x, y);
                    if (!t) continue;
                    float hb[4];
                    bool has = true;
                    if (t == 's') { hb[0] = .42f; hb[1] = .1f; hb[2] = .58f; hb[3] = .5f; }
                    else if (t == 'n') { hb[0] = .4f; hb[1] = .05f; hb[2] = .6f; hb[3] = .28f; }
                    else if (t == 'd') { hb[0] = .42f; hb[1] = .5f; hb[2] = .58f; hb[3] = .9f; }
                    else has = false;
                    if (has) dl->AddRect(ImVec2(v.X(x + hb[0]), v.Y(y + hb[3])), ImVec2(v.X(x + hb[2]), v.Y(y + hb[1])), red);
                    else if (t == 'w') dl->AddCircle(ImVec2(v.X(x + .5f), v.Y(y + .5f)), std::sqrt(.11f) * S, red, 20);
                    else if (t == 'p' || t == 'k') dl->AddRect(ImVec2(v.X((float)x), v.Y(y + .3f)), ImVec2(v.X(x + 1.f), v.Y((float)y)), red);
                    else if (t == 'c') dl->AddCircle(ImVec2(v.X(x + .5f), v.Y(y + .5f)), 1.1f * S, IM_COL32(255, 217, 59, 255), 24);
                }
            const bool w = P.m == Mode::Wave;
            dl->AddRect(ImVec2(v.X(P.x), v.Y(P.y + 1)), ImVec2(v.X(P.x + 1), v.Y(P.y)), IM_COL32(59, 155, 255, 255));
            float off = w ? .4f : .3f, z = w ? .2f : .4f;
            dl->AddRect(ImVec2(v.X(P.x + off), v.Y(P.y + off + z)), ImVec2(v.X(P.x + off + z), v.Y(P.y + off)), red);
        }
    }
    if (parts)
        for (auto& p : *parts) {
            float a = std::max(0.f, p.life / p.maxLife), s = p.size * S;
            dl->AddRectFilled(ImVec2(v.X(p.x) - s / 2, v.Y(p.y) - s / 2), ImVec2(v.X(p.x) + s / 2, v.Y(p.y) + s / 2), withAlpha(p.color, a));
        }
    dl->PopClipRect();
}

}  // namespace cd
