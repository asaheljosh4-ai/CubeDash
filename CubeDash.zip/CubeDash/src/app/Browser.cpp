#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <filesystem>

#include "App.h"

namespace fs = std::filesystem;
namespace cd {

std::string App::defaultBrowseDir() const {
#ifdef __ANDROID__
    return "/storage/emulated/0";
#else
    const char* h = std::getenv("HOME");
    if (!h) h = std::getenv("USERPROFILE");
    return h ? h : ".";
#endif
}

void App::openBrowser(const std::string& title, const std::vector<std::string>& exts, const std::string& startDir,
                      std::function<void(const std::string&)> cb) {
    browserTitle = title; browserExts = exts; browserCb = std::move(cb);
    std::error_code ec;
    browserDir = fs::is_directory(startDir, ec) ? startDir : "/";
    browserOpen = true;
}

void App::browserPopup() {
    if (browserOpen) { ImGui::OpenPopup("File browser"); browserOpen = false; }
    ImVec2 d = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(d / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
    ImGui::SetNextWindowSize(ImVec2(d.x * .9f, d.y * .9f));
    if (!ImGui::BeginPopupModal("File browser", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize)) return;
    ImGui::TextUnformatted(browserTitle.c_str());
    ImGui::TextDisabled("%s", browserDir.c_str());
    if (ImGui::Button("Up", ImVec2(70, 42))) { fs::path p = fs::path(browserDir).parent_path(); if (!p.empty()) browserDir = p.string(); }
    ImGui::SameLine();
    if (ImGui::Button("Music", ImVec2(90, 42))) browserDir = defaultBrowseDir() + "/Music";
    ImGui::SameLine();
    if (ImGui::Button("Download", ImVec2(110, 42))) browserDir = defaultBrowseDir() + "/Download";
    ImGui::SameLine();
    if (ImGui::Button("Home", ImVec2(80, 42))) browserDir = defaultBrowseDir();
    ImGui::SameLine();
    if (ImGui::Button("App data", ImVec2(110, 42))) browserDir = prefDir;
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(100, 42))) ImGui::CloseCurrentPopup();
    ImGui::Separator();
    std::error_code ec;
    std::vector<fs::directory_entry> dirs, files;
    for (auto& e : fs::directory_iterator(browserDir, fs::directory_options::skip_permission_denied, ec)) {
        std::error_code e2;
        if (e.is_directory(e2)) dirs.push_back(e);
        else {
            std::string x = e.path().extension().string();
            std::transform(x.begin(), x.end(), x.begin(), ::tolower);
            if (std::find(browserExts.begin(), browserExts.end(), x) != browserExts.end()) files.push_back(e);
        }
    }
    auto cmp = [](const fs::directory_entry& a, const fs::directory_entry& b) { return a.path().filename() < b.path().filename(); };
    std::sort(dirs.begin(), dirs.end(), cmp);
    std::sort(files.begin(), files.end(), cmp);
    if (ec) ImGui::TextColored(ImVec4(1, .6f, .3f, 1), "Cannot read this folder (permission?)");
    ImGui::BeginChild("##list", ImVec2(0, 0));
    touchScroll(true);
    std::string go, pick;
    int i = 0;
    auto row = [&](const std::string& label, const std::string& full, bool dir) {
        ImGui::PushID(i++);
        bool tap = ImGui::Selectable(label.c_str(), false, ImGuiSelectableFlags_None, ImVec2(0, 40));
        if (tap && std::fabs(ImGui::GetMouseDragDelta(0).y) < 10.f) (dir ? go : pick) = full;
        ImGui::PopID();
    };
    for (auto& e : dirs) row("[folder] " + e.path().filename().string(), e.path().string(), true);
    for (auto& e : files) row(e.path().filename().string(), e.path().string(), false);
    ImGui::EndChild();
    if (!go.empty()) browserDir = go;
    if (!pick.empty()) { auto cb = browserCb; ImGui::CloseCurrentPopup(); if (cb) cb(pick); }
    ImGui::EndPopup();
}

}  // namespace cd
