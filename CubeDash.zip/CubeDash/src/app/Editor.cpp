#include <algorithm>
#include <cmath>
#include <cstdio>
#include <filesystem>

#include "App.h"
#include "misc/cpp/imgui_stdlib.h"

namespace fs = std::filesystem;

namespace cd {

namespace {
const char* toolName(char t) {
    switch (t) {
        case 'm': return "Pan";
        case 'e': return "Erase";
        case 'X': return "Start position";
        default: return objectName(t);
    }
}
}  // namespace

// ---------------------------------------------------------------- undo / redo
Snap App::snapshot() const {
    Snap s;
    s.obj = lv.obj; s.hasStart = lv.hasStart; s.sx = lv.startX; s.sy = lv.startY; s.sm = lv.startMode;
    return s;
}
void App::restore(const Snap& s) {
    lv.obj = s.obj; lv.hasStart = s.hasStart; lv.startX = s.sx; lv.startY = s.sy; lv.startMode = s.sm;
}
void App::pushUndo(const Snap& s) {
    hist.push_back(s);
    if (hist.size() > 100) hist.erase(hist.begin());
    redoStack.clear();
    dirty = true;
}
void App::undo() {
    if (hist.empty()) return;
    redoStack.push_back(snapshot());
    restore(hist.back());
    hist.pop_back();
    dirty = true;
}
void App::redo() {
    if (redoStack.empty()) return;
    hist.push_back(snapshot());
    restore(redoStack.back());
    redoStack.pop_back();
    dirty = true;
}

// ---------------------------------------------------------------- open / save / leave
void App::openEditor(const Level& l, const std::string& path) {
    lv = l;
    filePath = path;
    dirty = false;
    tool = 'b';
    hist.clear(); redoStack.clear();
    zoom = 1.f;
    ed.camX = -2.f; ed.camY = -2.4f;
    stroking = panning = previewing = confirmExit = false;
    showMath = showMusic = false;
    musicInput = lv.musicPath;
    audio.stopMusic();
    if (!lv.musicPath.empty() && fs::exists(lv.musicPath)) loadMusicFor(lv.musicPath, false);
    else audio.unloadMusic();
    screen = Screen::Editor;
}

void App::loadMusicFor(const std::string& path, bool announce) {
    std::string err;
    if (!fs::exists(path)) { if (announce) toast("File not found"); return; }
    if (audio.loadMusic(path, &err)) {
        lv.musicPath = path;
        musicInput = path;
        if (announce) { toast("Music loaded: " + fs::path(path).filename().string()); dirty = true; }
    } else if (announce) {
        toast("Could not load music: " + err);
    }
}

bool App::saveCurrent() {
    std::string path = filePath.empty() ? userDir + "/" + slug(lv.name) + ".cdl" : filePath;
    if (saveLevel(lv, path)) {
        filePath = path;
        dirty = false;
        refreshLibrary();
        toast("Saved " + fs::path(path).filename().string());
        return true;
    }
    toast("Save failed");
    return false;
}

bool App::publishCurrent() {
    lv.official = true;
    std::string path = officialDir + "/" + slug(lv.name) + ".cdl";
    if (saveLevel(lv, path)) {
        filePath = path;
        dirty = false;
        refreshLibrary();
        toast("Published as main level: " + lv.name);
        return true;
    }
    toast("Publish failed");
    return false;
}

void App::requestExit() {
    if (dirty) confirmExit = true;
    else leaveEditor();
}

void App::leaveEditor() {
    audio.stopMusic();
    previewing = false;
    refreshLibrary();
    screen = filePath.empty() ? Screen::Menu : Screen::Select;
}

// ---------------------------------------------------------------- painting
void App::paintAt(int x, int y, bool erase) {
    if (x < 0 || y < 0 || y > kMaxY) return;
    if (erase || tool == 'e') {
        if (lv.erase(x, y)) strokeChanged = true;
    } else if (tool == 'X') {
        if (!lv.hasStart || lv.startX != x || lv.startY != y) { lv.hasStart = true; lv.startX = x; lv.startY = y; strokeChanged = true; }
    } else if (tool != 'm') {
        if (lv.get(x, y) != tool) { lv.set(x, y, tool); strokeChanged = true; }
    }
}

void App::paintLine(int x0, int y0, int x1, int y1, bool erase) {
    int dx = std::abs(x1 - x0), dy = std::abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx - dy;
    for (int i = 0; i < 600; i++) {
        paintAt(x0, y0, erase);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * e;
        if (e2 > -dy) { e -= dy; x0 += sx; }
        if (e2 < dx) { e += dx; y0 += sy; }
    }
}

// ---------------------------------------------------------------- world input
void App::edInput(float dt, ImVec2 disp) {
    ImGuiIO& io = ImGui::GetIO();
    const float baseS = std::min(disp.y / 11.f, disp.x / 9.f);
    ed.origin = ImVec2(0, 0);
    ed.size = disp;
    ed.S = baseS * zoom;
    const ImVec2 m = io.MousePos;
    const bool over = io.WantCaptureMouse && !stroking && !panning;
    const bool typing = io.WantTextInput;
    if (!over) { hoverX = (int)std::floor(ed.worldX(m.x)); hoverY = (int)std::floor(ed.worldY(m.y)); }
    else hoverX = hoverY = -1;

    if (previewing) {
        if (audio.musicPlaying()) ed.camX = (audio.musicPos() - lv.musicOffset) * kSpeed[lv.speed] - disp.x / ed.S * .3f;
        else previewing = false;
    }

    if (touchCount >= 2) {  // two-finger pinch: zoom + pan, cancels any stroke started by the first finger
        if (stroking) { restore(strokeSnap); stroking = false; }
        panning = false;
        if (pinchActive) {
            float prevX = pinchX - pinchDx, prevY = pinchY - pinchDy;
            float wx = ed.worldX(prevX), wy = ed.worldY(prevY);
            zoom = std::clamp(zoom * (pinchZoom > 0 ? pinchZoom : 1.f), .3f, 3.f);
            ed.S = baseS * zoom;
            ed.camX = wx - (pinchX - ed.origin.x) / ed.S;
            ed.camY = std::max(-4.f, wy - (ed.origin.y + ed.size.y - pinchY) / ed.S);
            pinchZoom = 0; pinchDx = pinchDy = 0; previewing = false;
        }
    }
    if (!over && io.MouseWheel != 0.f) {
        if (io.KeyShift) ed.camX -= io.MouseWheel * 3.f / zoom;
        else {
            float wx = ed.worldX(m.x), wy = ed.worldY(m.y);
            zoom = std::clamp(zoom * (io.MouseWheel > 0 ? 1.1f : 1.f / 1.1f), .3f, 3.f);
            ed.S = baseS * zoom;
            ed.camX = wx - (m.x - ed.origin.x) / ed.S;
            ed.camY = wy - (ed.origin.y + ed.size.y - m.y) / ed.S;
        }
    }
    if (!typing) {
        const float k = 14.f * dt / std::max(.4f, zoom);
        if (ImGui::IsKeyDown(ImGuiKey_A) || ImGui::IsKeyDown(ImGuiKey_LeftArrow)) ed.camX -= k;
        if (ImGui::IsKeyDown(ImGuiKey_D) || ImGui::IsKeyDown(ImGuiKey_RightArrow)) ed.camX += k;
        if (ImGui::IsKeyDown(ImGuiKey_W) || ImGui::IsKeyDown(ImGuiKey_UpArrow)) ed.camY += k;
        if (ImGui::IsKeyDown(ImGuiKey_S) && !io.KeyCtrl) ed.camY -= k;
        if (ImGui::IsKeyDown(ImGuiKey_DownArrow)) ed.camY -= k;
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z, false)) { if (io.KeyShift) redo(); else undo(); }
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y, false)) redo();
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_S, false)) saveCurrent();
        if (ImGui::IsKeyPressed(ImGuiKey_Enter, false)) { startPlay(lv, io.KeyShift && lv.hasStart, Screen::Editor); return; }
    }
    ed.camY = std::max(-4.f, ed.camY);

    // pan
    const bool spaceHeld = !typing && ImGui::IsKeyDown(ImGuiKey_Space);
    if (!stroking && !panning && !over && touchCount < 2) {
        if (ImGui::IsMouseClicked(2) || (ImGui::IsMouseClicked(0) && (tool == 'm' || spaceHeld))) panning = true;
    }
    if (panning) {
        if (!ImGui::IsMouseDown(0) && !ImGui::IsMouseDown(2)) panning = false;
        else { previewing = false; ed.camX -= io.MouseDelta.x / ed.S; ed.camY = std::max(-4.f, ed.camY + io.MouseDelta.y / ed.S); }
    }

    // paint strokes
    if (!stroking && !panning && !over && touchCount < 2 && (ImGui::IsMouseClicked(0) || ImGui::IsMouseClicked(1))) {
        stroking = true;
        strokeErase = ImGui::IsMouseClicked(1);
        strokeChanged = false;
        strokeSnap = snapshot();
        lastCx = hoverX; lastCy = hoverY;
        paintAt(hoverX, hoverY, strokeErase);
    }
    if (stroking) {
        const int cx = (int)std::floor(ed.worldX(m.x)), cy = (int)std::floor(ed.worldY(m.y));
        if (ImGui::IsMouseDown(strokeErase ? 1 : 0)) {
            if (cx != lastCx || cy != lastCy) { paintLine(lastCx, lastCy, cx, cy, strokeErase); lastCx = cx; lastCy = cy; }
        } else {
            if (strokeChanged) pushUndo(strokeSnap);
            stroking = false;
        }
    }
}

// ---------------------------------------------------------------- UI panels
void App::edToolbar(ImVec2 disp) {
    ImGui::SetNextWindowPos(ImVec2(8, 8));
    ImGui::SetNextWindowSize(ImVec2(disp.x - 16, 0));
    ImGui::Begin("##toolbar", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_HorizontalScrollbar);
    if (ImGui::Button("< Menu")) requestExit();
    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(.18f, .72f, .30f, .95f));
    if (ImGui::Button("  PLAY  ")) { ImGui::PopStyleColor(); startPlay(lv, false, Screen::Editor); ImGui::End(); return; }
    ImGui::PopStyleColor();
    ImGui::SameLine();
    ImGui::BeginDisabled(!lv.hasStart);
    if (ImGui::Button("Play from Start Pos")) { startPlay(lv, true, Screen::Editor); ImGui::EndDisabled(); ImGui::End(); return; }
    ImGui::EndDisabled();
    if (!lv.hasStart && ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("Place a Start position first (palette > Start pos)");
    ImGui::SameLine();
    ImGui::BeginDisabled(hist.empty());
    if (ImGui::Button("Undo")) undo();
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::BeginDisabled(redoStack.empty());
    if (ImGui::Button("Redo")) redo();
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(std::clamp(disp.x * .14f, 110.f, 220.f));
    if (ImGui::InputText("##name", &lv.name)) dirty = true;
    ImGui::SameLine();
    if (ImGui::Button(dirty ? "Save*" : "Save")) saveCurrent();
    ImGui::SameLine();
    if (ImGui::Button("Export")) {
        std::error_code ec;
        fs::create_directories(prefDir + "exports", ec);
        std::string dest = prefDir + "exports/" + slug(lv.name) + ".cdl";
        toast(saveLevel(lv, dest) ? "Exported to " + dest : "Export failed");
    }
    if (st.dev) {
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1.f, .43f, .24f, .85f));
        if (ImGui::Button(lv.official ? "Update Main Level" : "Publish Main Level")) publishCurrent();
        ImGui::PopStyleColor();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Level", &showLevel);
    ImGui::SameLine();
    ImGui::Checkbox("Math", &showMath);
    ImGui::SameLine();
    ImGui::Checkbox("Music", &showMusic);
    ImGui::SameLine();
    if (ImGui::Button("Settings")) openSettings = true;
    ImGui::End();
}

void App::edPalette(ImVec2 disp) {
    ImGui::SetNextWindowPos(ImVec2(8, 76));
    ImGui::SetNextWindowSizeConstraints(ImVec2(150, 0), ImVec2(150, std::max(200.f, disp.y - 130)));
    ImGui::Begin("Palette", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize);
    touchScroll(false);
    int n = 0;
    auto tile = [&](char t) {
        ImGui::PushID((int)t);
        ImVec2 p = ImGui::GetCursorScreenPos();
        if (ImGui::InvisibleButton("##t", ImVec2(60, 60))) tool = t;
        bool hov = ImGui::IsItemHovered(), sel = tool == t;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(p, p + ImVec2(60, 60), sel ? IM_COL32(91, 227, 255, 90) : hov ? IM_COL32(255, 255, 255, 36) : IM_COL32(255, 255, 255, 14), 12);
        if (sel) dl->AddRect(p, p + ImVec2(60, 60), IM_COL32(91, 227, 255, 255), 12, 0, 2.f);
        drawToolIcon(dl, t, p + ImVec2(30, 30), 34.f);
        if (hov) ImGui::SetTooltip("%s", toolName(t));
        ImGui::PopID();
        if (++n % 2) ImGui::SameLine();
    };
    ImGui::TextDisabled("Tools");
    n = 0;
    for (char t : {'m', 'e', 'X'}) tile(t);
    if (n % 2) { n = 0; ImGui::NewLine(); }
    std::string last;
    for (auto& o : objectTable()) {
        if (last != o.group) {
            if (n % 2) { ImGui::NewLine(); }
            n = 0;
            ImGui::Spacing();
            ImGui::TextDisabled("%s", o.group);
            last = o.group;
        }
        tile(o.tag);
    }
    if (n % 2) ImGui::NewLine();
    ImGui::End();
}

void App::edLevelPanel(ImVec2 disp) {
    if (!showLevel) return;
    ImGui::SetNextWindowPos(ImVec2(disp.x - 8, 76), ImGuiCond_FirstUseEver, ImVec2(1, 0));
    ImGui::SetNextWindowSize(ImVec2(300, 0), ImGuiCond_Always);
    ImGui::Begin("Level", &showLevel, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize);
    if (ImGui::InputText("Author", &lv.author)) dirty = true;
    ImGui::Text("Difficulty");
    static const char* dn[3] = {"Easy", "Normal", "Hard"};
    for (int i = 0; i < 3; i++) {
        ImGui::PushID(i);
        ImVec2 p = ImGui::GetCursorScreenPos();
        if (ImGui::InvisibleButton("##d", ImVec2(60, 60))) { lv.diff = i; dirty = true; }
        ImDrawList* dl = ImGui::GetWindowDrawList();
        if (lv.diff == i) dl->AddRect(p, p + ImVec2(60, 60), IM_COL32(91, 227, 255, 255), 12, 0, 2.f);
        drawFace(dl, p + ImVec2(30, 28), 20.f, i);
        ImVec2 ts = ImGui::CalcTextSize(dn[i]);
        dl->AddText(p + ImVec2(30 - ts.x / 2, 47), IM_COL32_WHITE, dn[i]);
        ImGui::PopID();
        ImGui::SameLine();
    }
    ImGui::NewLine();
    int sp = lv.speed;
    if (ImGui::SliderInt("Speed", &sp, 0, kSpeedCount - 1, kSpeedLabel[std::clamp(sp, 0, kSpeedCount - 1)])) { lv.speed = sp; dirty = true; }
    static const char* bgn[3] = {"Static", "Slow shift", "Fast shift"};
    if (ImGui::Combo("Background", &lv.bg, bgn, 3)) dirty = true;
    ImGui::BeginDisabled(!lv.hasStart);
    static const char* modes[4] = {"Cube", "Ship", "Ball", "Wave"};
    int mi = lv.startMode == 's' ? 1 : lv.startMode == 'b' ? 2 : lv.startMode == 'w' ? 3 : 0;
    if (ImGui::Combo("Start mode", &mi, modes, 4)) { lv.startMode = "csbw"[mi]; dirty = true; }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (lv.hasStart && ImGui::SmallButton("Remove")) { Snap s = snapshot(); lv.hasStart = false; pushUndo(s); }
    if (st.dev) { if (ImGui::Checkbox("Main level (official)", &lv.official)) dirty = true; }
    ImGui::Separator();
    ImGui::Checkbox("Grid", &st.grid);
    ImGui::SameLine();
    ImGui::Checkbox("Beat lines", &showBeats);
    ImGui::Text("%zu objects  |  %d coins  |  end x = %d", lv.obj.size(), lv.coins(), lv.endX());
    if (ImGui::Button("Clear level", ImVec2(-1, 0))) { Snap s = snapshot(); lv.clear(); pushUndo(s); }
    ImGui::End();
}

void App::edMathPanel(ImVec2 disp) {
    if (!showMath) return;
    ImGui::SetNextWindowPos(ImVec2(disp.x - 8, disp.y - 44), ImGuiCond_FirstUseEver, ImVec2(1, 1));
    ImGui::SetNextWindowSize(ImVec2(340, 0), ImGuiCond_Always);
    ImGui::Begin("Math Placement", &showMath, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize);
    const bool canPlace = tool != 'm' && tool != 'X';
    ImGui::Text("Tool: %s%s", toolName(tool), canPlace ? "" : "  (pick an object or erase)");
    auto put = [&](int x, int y) {
        if (x < 0 || y < 0 || y > kMaxY) return;
        if (tool == 'e') lv.erase(x, y); else lv.set(x, y, tool);
    };
    ImGui::SeparatorText("Exact cell");
    ImGui::SetNextItemWidth(90); ImGui::InputInt("X##p", &mpX, 1, 5);
    ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::InputInt("Y##p", &mpY, 1, 5);
    if (ImGui::Button("Use hovered") && hoverX >= 0) { mpX = hoverX; mpY = hoverY; }
    ImGui::SameLine();
    ImGui::BeginDisabled(!canPlace);
    if (ImGui::Button("Place")) { Snap s = snapshot(); put(mpX, mpY); pushUndo(s); }
    ImGui::EndDisabled();

    ImGui::SeparatorText("Repeat");
    ImGui::SetNextItemWidth(70); ImGui::InputInt("Count", &mrCount, 0, 0);
    ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::InputInt("dX", &mrDx, 0, 0);
    ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::InputInt("dY", &mrDy, 0, 0);
    ImGui::BeginDisabled(!canPlace);
    if (ImGui::Button("Repeat from cell")) {
        Snap s = snapshot();
        for (int i = 0; i < std::clamp(mrCount, 0, 5000); i++) put(mpX + i * mrDx, mpY + i * mrDy);
        pushUndo(s);
    }
    ImGui::EndDisabled();

    ImGui::SeparatorText("Fill rectangle");
    ImGui::SetNextItemWidth(70); ImGui::InputInt("x0", &mfx0, 0, 0);
    ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::InputInt("y0", &mfy0, 0, 0);
    ImGui::SetNextItemWidth(70); ImGui::InputInt("x1", &mfx1, 0, 0);
    ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::InputInt("y1", &mfy1, 0, 0);
    ImGui::BeginDisabled(!canPlace);
    if (ImGui::Button("Fill / erase area")) {
        Snap s = snapshot();
        int xa = std::min(mfx0, mfx1), xb = std::max(mfx0, mfx1), ya = std::min(mfy0, mfy1), yb = std::max(mfy0, mfy1);
        if ((long long)(xb - xa + 1) * (yb - ya + 1) > 20000) toast("Area too large (max 20000 cells)");
        else { for (int x = xa; x <= xb; x++) for (int y = ya; y <= yb; y++) put(x, y); pushUndo(s); }
    }
    ImGui::EndDisabled();

    ImGui::SeparatorText("Shift level");
    ImGui::SetNextItemWidth(70); ImGui::InputInt("from x", &mshX, 0, 0);
    ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::InputInt("by", &mshDx, 0, 0);
    ImGui::SameLine();
    if (ImGui::Button("Shift")) {
        Snap s = snapshot();
        std::unordered_map<int64_t, char> n;
        for (auto& kv : lv.obj) {
            int x = keyX(kv.first), y = keyY(kv.first);
            if (x >= mshX) x += mshDx;
            if (x >= 0) n[cellKey(x, y)] = kv.second;
        }
        lv.obj.swap(n);
        if (lv.hasStart && lv.startX >= mshX) lv.startX = std::max(0, lv.startX + mshDx);
        pushUndo(s);
    }

    ImGui::SeparatorText("Beat snap");
    static int beat = 16;
    ImGui::SetNextItemWidth(90); ImGui::InputInt("Beat", &beat, 1, 4);
    const float bx = kSpeed[lv.speed] * (beat * 60.f / std::max(20.f, lv.bpm) - lv.musicOffset);
    ImGui::SameLine();
    ImGui::Text("= x %d", (int)std::lround(bx));
    if (ImGui::Button("Set X to beat")) mpX = (int)std::lround(bx);
    ImGui::SameLine();
    if (ImGui::Button("Jump camera")) ed.camX = bx - 3.f;
    ImGui::End();
}

void App::edMusicPanel(ImVec2 disp) {
    if (!showMusic) return;
    ImGui::SetNextWindowPos(ImVec2(disp.x / 2, disp.y - 44), ImGuiCond_FirstUseEver, ImVec2(.5f, 1));
    ImGui::SetNextWindowSize(ImVec2(std::min(560.f, disp.x - 40), 0), ImGuiCond_Always);
    ImGui::Begin("Music Importer", &showMusic, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize);
    if (ImGui::Button("Browse...")) {
        openBrowser("Choose a song", {".mp3", ".ogg", ".wav", ".flac", ".m4a", ".opus", ".aac", ".mod", ".xm", ".it", ".s3m"}, defaultBrowseDir(),
                    [this](const std::string& f) { loadMusicFor(f, true); });
    }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(-130);
    ImGui::InputTextWithHint("##path", "...or paste a path / drop a file onto the window", &musicInput);
    ImGui::SameLine();
    if (ImGui::Button("Load")) loadMusicFor(musicInput, true);
    ImGui::SameLine();
    if (ImGui::Button("Remove")) { audio.unloadMusic(); lv.musicPath.clear(); musicInput.clear(); previewing = false; dirty = true; }

    if (audio.hasMusic()) {
        ImGui::Text("%s  (%d:%02d)", fs::path(audio.musicPath()).filename().string().c_str(), (int)audio.musicLength() / 60, (int)audio.musicLength() % 60);
        if (!audio.peaks().empty()) ImGui::PlotLines("##wave", audio.peaks().data(), (int)audio.peaks().size(), 0, nullptr, 0.f, 1.f, ImVec2(-1, 80));
    } else {
        ImGui::TextDisabled("No song loaded. The path is stored in the level file.");
        if (!lv.musicPath.empty()) ImGui::TextColored(ImVec4(1, .6f, .3f, 1), "Level references: %s", lv.musicPath.c_str());
    }
    ImGui::Separator();
    if (ImGui::InputFloat("BPM", &lv.bpm, 0.5f, 5.f, "%.2f")) { lv.bpm = std::clamp(lv.bpm, 20.f, 400.f); dirty = true; }
    ImGui::SameLine();
    if (ImGui::Button("Tap")) {
        double now = ImGui::GetTime();
        if (now - lastTap > 2.0) taps.clear();
        else if (lastTap > 0) taps.push_back((float)(now - lastTap));
        lastTap = now;
        if (taps.size() >= 3) {
            float sum = 0; for (float t : taps) sum += t;
            lv.bpm = std::clamp(60.f * taps.size() / sum, 20.f, 400.f);
            dirty = true;
        }
    }
    if (ImGui::DragFloat("Offset (s)", &lv.musicOffset, 0.005f, -30.f, 120.f, "%.3f")) dirty = true;
    ImGui::SameLine();
    if (ImGui::SmallButton("-0.01")) { lv.musicOffset -= .01f; dirty = true; }
    ImGui::SameLine();
    if (ImGui::SmallButton("+0.01")) { lv.musicOffset += .01f; dirty = true; }
    ImGui::TextDisabled("Offset = seconds of song that have already played when the cube is at x = 0.");
    ImGui::Checkbox("Show beat lines in editor", &showBeats);
    ImGui::BeginDisabled(!audio.hasMusic());
    if (!previewing) {
        if (ImGui::Button("Preview from camera")) {
            float x0 = ed.camX + disp.x / ed.S * .3f;
            audio.playMusic(lv.musicOffset + x0 / kSpeed[lv.speed]);
            previewing = true;
        }
    } else if (ImGui::Button("Stop preview")) { audio.stopMusic(); previewing = false; }
    ImGui::EndDisabled();
    ImGui::End();
}

// ---------------------------------------------------------------- frame
void App::editorFrame(float dt) {
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    edInput(dt, disp);
    if (screen != Screen::Editor) return;
    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopupId) && !ImGui::GetIO().WantTextInput) requestExit();

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    DrawOpts o;
    o.grid = st.grid;
    o.beatLines = showBeats && !lv.musicPath.empty();
    o.time = time;
    o.bg = lv.bg;
    o.bpm = lv.bpm;
    o.musicOffset = lv.musicOffset;
    o.speed = lv.speed;
    drawLevel(dl, lv, ed, o, nullptr, nullptr, 0.f);

    if (hoverX >= 0 && hoverY >= 0 && hoverY <= kMaxY && tool != 'm') {
        ImVec2 tl(ed.X((float)hoverX), ed.Y((float)hoverY + 1));
        ImVec2 br(tl.x + ed.S, tl.y + ed.S);
        if (tool == 'e') dl->AddRect(tl, br, IM_COL32(255, 77, 77, 255), 0, 0, 2.f);
        else {
            if (tool != 'X') drawObject(dl, tool, tl, ed.S, .5f, time, (float)hoverX);
            dl->AddRect(tl, br, tool == 'X' ? IM_COL32(125, 255, 79, 255) : IM_COL32(255, 217, 59, 255), 0, 0, 1.5f);
        }
    }

    edToolbar(disp);
    if (screen != Screen::Editor) return;
    edPalette(disp);
    edLevelPanel(disp);
    edMathPanel(disp);
    edMusicPanel(disp);

    // status bar
    ImGui::SetNextWindowPos(ImVec2(8, disp.y - 8), ImGuiCond_Always, ImVec2(0, 1));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 5));
    ImGui::Begin("##status", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoInputs);
    if (hoverX >= 0) ImGui::Text("x %d   y %d   |  %zu objects  |  %d%%  |  %s  |  speed %s%s", hoverX, hoverY, lv.obj.size(), (int)std::lround(zoom * 100),
                                 toolName(tool), kSpeedLabel[lv.speed], dirty ? "  |  unsaved" : "");
    else ImGui::Text("%zu objects  |  %d%%  |  %s  |  speed %s%s", lv.obj.size(), (int)std::lround(zoom * 100), toolName(tool), kSpeedLabel[lv.speed], dirty ? "  |  unsaved" : "");
    ImGui::End();
    ImGui::PopStyleVar();

    // unsaved changes dialog
    if (confirmExit) { ImGui::OpenPopup("Unsaved changes"); confirmExit = false; }
    ImGui::SetNextWindowPos(disp / 2, ImGuiCond_Always, ImVec2(.5f, .5f));
    if (ImGui::BeginPopupModal("Unsaved changes", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Save \"%s\" before leaving?", lv.name.c_str());
        if (ImGui::Button("Save & leave", ImVec2(130, 38))) { if (saveCurrent()) { ImGui::CloseCurrentPopup(); leaveEditor(); } }
        ImGui::SameLine();
        if (ImGui::Button("Discard", ImVec2(110, 38))) { ImGui::CloseCurrentPopup(); dirty = false; leaveEditor(); }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(110, 38))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

}  // namespace cd
