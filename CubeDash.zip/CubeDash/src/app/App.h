#pragma once
// CubeDash application: main menu, level select, level editor + music importer, gameplay.
#include <SDL.h>

#include <functional>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "../audio/Audio.h"
#include "../core/Level.h"
#include "../core/Sim.h"
#include "Draw.h"

namespace cd {

struct Settings {
    float master = .8f, music = .8f, sfx = .8f;
    bool hitboxes = false, grid = true, practice = false, fullscreen = false, dev = false;
};

struct LevelEntry {
    std::string path;
    Level lv;
};

struct Snap {
    std::unordered_map<int64_t, char> obj;
    bool hasStart = false;
    int sx = 0, sy = 0;
    char sm = 'c';
};

enum class Screen { Menu, Select, Editor, Play };

void touchScroll(bool allowActive);  // drag-to-scroll for ImGui windows on touch screens

class App {
public:
    bool init(SDL_Window* window, bool devFlag);
    void shutdown();
    void frame(float dt);  // build UI + draw the current screen
    void onDrop(const std::string& path);
    // touch gestures forwarded by main.cpp (coordinates already in UI space)
    void onTouchCount(int n);
    void onPinch(float midX, float midY, float scale, float dx, float dy);
    void setUiScale(float s) { uiScale = s; }
    bool quit = false;

private:
    // ---- infrastructure
    SDL_Window* win = nullptr;
    Audio audio;
    Settings st;
    float time = 0, uiScale = 1.f;
    int touchCount = 0;
    float pinchZoom = 0, pinchDx = 0, pinchDy = 0, pinchX = 0, pinchY = 0;
    bool pinchActive = false;
    std::string prefDir, officialDir, userDir;
    std::map<std::string, int> bests;
    std::vector<LevelEntry> mainLevels, myLevels;
    Screen screen = Screen::Menu;
    int selectTab = 0;  // 0 main, 1 mine
    bool openSettings = false;
    std::string toastMsg;
    float toastT = 0;

    void toast(const std::string& m) { toastMsg = m; toastT = 2.f; }
    void applyStyle();
    void loadSettings();
    void saveSettings();
    void loadBests();
    void saveBests();
    void refreshLibrary();
    void ensureOfficial();
    std::string slug(const std::string& n) const;
    void applyAudio() { audio.setVolumes(st.master, st.music, st.sfx); }
    void drawToast(ImDrawList* dl, ImVec2 disp);
    void settingsPopup();

    // ---- in-app file browser (works on desktop and Android)
    bool browserOpen = false;
    std::string browserDir, browserTitle;
    std::vector<std::string> browserExts;
    std::function<void(const std::string&)> browserCb;
    void openBrowser(const std::string& title, const std::vector<std::string>& exts, const std::string& startDir,
                     std::function<void(const std::string&)> cb);
    void browserPopup();
    std::string defaultBrowseDir() const;

    // ---- screens
    void menuFrame(float dt);
    void selectFrame();

    // ---- editor
    Level lv;
    std::string filePath;
    bool dirty = false;
    char tool = 'b';
    std::vector<Snap> hist, redoStack;
    View ed;
    float zoom = 1.f;
    bool stroking = false, strokeChanged = false, strokeErase = false, panning = false;
    int lastCx = 0, lastCy = 0;
    Snap strokeSnap;
    int hoverX = -1, hoverY = -1;
    bool showMath = false, showMusic = false, showLevel = true, showBeats = true;
    // math placement
    int mpX = 10, mpY = 0, mfx0 = 10, mfy0 = 0, mfx1 = 20, mfy1 = 0, mrCount = 4, mrDx = 4, mrDy = 0, mshX = 20, mshDx = 4;
    // music importer
    std::string musicInput;
    bool previewing = false;
    std::vector<float> taps;
    double lastTap = 0;
    bool confirmExit = false;

    Snap snapshot() const;
    void restore(const Snap& s);
    void pushUndo(const Snap& s);
    void undo();
    void redo();
    void openEditor(const Level& l, const std::string& path);
    void editorFrame(float dt);
    void edToolbar(ImVec2 disp);
    void edPalette(ImVec2 disp);
    void edLevelPanel(ImVec2 disp);
    void edMathPanel(ImVec2 disp);
    void edMusicPanel(ImVec2 disp);
    void edInput(float dt, ImVec2 disp);
    void paintAt(int x, int y, bool erase);
    void paintLine(int x0, int y0, int x1, int y1, bool erase);
    bool saveCurrent();
    bool publishCurrent();
    void loadMusicFor(const std::string& path, bool announce);
    void requestExit();
    void leaveEditor();

    // ---- play
    Level playLevel;
    Sim sim;
    Screen returnTo = Screen::Menu;
    std::vector<Particle> parts;
    bool paused = false, prevHeld = false, endShown = false, fromEditorStart = false;
    float deathT = 0, winT = 0, shake = 0, flash = 0, simAcc = 0;
    float playCamX = 0, playCamY = -1.5f;
    void startPlay(const Level& l, bool useStart, Screen ret);
    void playFrame(float dt);
    void handleEvents();
    void burst(float x, float y, int n, std::vector<ImU32> cols, float spd, float life, float sz, float gr);
    void exitPlay();
    void restartPlay();
    void playMusicAtSim();
};

}  // namespace cd
