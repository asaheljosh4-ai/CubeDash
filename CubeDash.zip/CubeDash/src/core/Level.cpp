#include "Level.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>

namespace cd {

const std::vector<ObjInfo>& objectTable() {
    static const std::vector<ObjInfo> t = {
        {'b', "Block", "Blocks"},      {'l', "Slab", "Blocks"},
        {'s', "Spike", "Spikes"},      {'n', "Mini spike", "Spikes"},
        {'d', "Roof spike", "Spikes"}, {'w', "Saw", "Spikes"},
        {'p', "Yellow pad", "Boost"},  {'k', "Pink pad", "Boost"},
        {'o', "Yellow orb", "Boost"},  {'q', "Pink orb", "Boost"},
        {'C', "Cube portal", "Modes"}, {'S', "Ship portal", "Modes"},
        {'B', "Ball portal", "Modes"}, {'W', "Wave portal", "Modes"},
        {'c', "Secret coin", "Coin"},
    };
    return t;
}
const char* objectName(char tag) {
    for (auto& o : objectTable())
        if (o.tag == tag) return o.name;
    return "?";
}
bool isPortal(char t) { return t == 'C' || t == 'S' || t == 'B' || t == 'W'; }
float solidHeight(char t) { return t == 'b' ? 1.f : t == 'l' ? .5f : 0.f; }
bool isSolid(char t) { return solidHeight(t) > 0; }

int Level::coins() const {
    int n = 0;
    for (auto& kv : obj) n += kv.second == 'c';
    return n;
}
int Level::endX() const {
    int m = 0;
    for (auto& kv : obj) m = std::max(m, keyX(kv.first));
    return m + 10;
}

bool saveLevel(const Level& l, const std::string& path) {
    std::ofstream f(path);
    if (!f) return false;
    auto clean = [](std::string s) {
        for (auto& c : s)
            if (c == '\n' || c == '\r') c = ' ';
        return s;
    };
    f << "CDL1\n";
    f << "name=" << clean(l.name) << "\nauthor=" << clean(l.author) << "\n";
    f << "diff=" << l.diff << "\nspeed=" << l.speed << "\nbg=" << l.bg << "\n";
    f << "bpm=" << l.bpm << "\noffset=" << l.musicOffset << "\n";
    f << "official=" << (l.official ? 1 : 0) << "\n";
    if (!l.musicPath.empty()) f << "music=" << clean(l.musicPath) << "\n";
    if (l.hasStart) f << "start=" << l.startX << "," << l.startY << "," << l.startMode << "\n";
    f << "objects\n";
    std::vector<int64_t> keys;
    keys.reserve(l.obj.size());
    for (auto& kv : l.obj) keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (auto k : keys) f << l.obj.at(k) << ' ' << keyX(k) << ' ' << keyY(k) << '\n';
    return bool(f);
}

bool loadLevel(Level& l, const std::string& path) {
    std::ifstream f(path);
    if (!f) return false;
    std::string line;
    if (!std::getline(f, line) || line.rfind("CDL1", 0) != 0) return false;
    Level n;
    bool inObjects = false;
    while (std::getline(f, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty()) continue;
        if (!inObjects) {
            if (line == "objects") { inObjects = true; continue; }
            auto eq = line.find('=');
            if (eq == std::string::npos) continue;
            std::string k = line.substr(0, eq), v = line.substr(eq + 1);
            if (k == "name") n.name = v;
            else if (k == "author") n.author = v;
            else if (k == "diff") n.diff = std::clamp(atoi(v.c_str()), 0, 2);
            else if (k == "speed") n.speed = std::clamp(atoi(v.c_str()), 0, 4);
            else if (k == "bg") n.bg = std::clamp(atoi(v.c_str()), 0, 2);
            else if (k == "bpm") n.bpm = std::clamp((float)atof(v.c_str()), 20.f, 400.f);
            else if (k == "offset") n.musicOffset = (float)atof(v.c_str());
            else if (k == "official") n.official = atoi(v.c_str()) != 0;
            else if (k == "music") n.musicPath = v;
            else if (k == "start") {
                int x = 0, y = 0; char m = 'c';
                if (sscanf(v.c_str(), "%d,%d,%c", &x, &y, &m) >= 2) {
                    n.hasStart = true; n.startX = std::max(0, x); n.startY = std::clamp(y, 0, kMaxY);
                    n.startMode = (m == 's' || m == 'b' || m == 'w') ? m : 'c';
                }
            }
        } else {
            char t; int x, y;
            if (sscanf(line.c_str(), " %c %d %d", &t, &x, &y) == 3 && x >= 0 && y >= 0 && y <= kMaxY)
                n.set(x, y, t);
        }
    }
    l = std::move(n);
    return true;
}

// ------------------------------------------------------------ built-in levels
static void add(Level& l, char t, int x, int y) { l.set(x, y, t); }

Level makeDemoLevel() {
    Level l; l.name = "Stereo Start"; l.author = "CubeDash"; l.diff = 0; l.official = true; l.bpm = 128;
    for (int x : {10, 16, 17, 24, 25, 26}) add(l, 's', x, 0);
    for (int x = 30; x < 34; x++) add(l, 'b', x, 0);
    add(l, 'b', 31, 1); add(l, 'n', 35, 0); add(l, 'p', 38, 0); add(l, 'b', 42, 3);
    add(l, 'o', 46, 2); add(l, 's', 50, 0); add(l, 'S', 56, 2);
    for (int x = 60; x < 100; x += 8) {
        add(l, 'b', x, 0); add(l, 'b', x, 1); add(l, 'b', x, 8); add(l, 'b', x, 9); add(l, 'd', x + 4, 8);
    }
    add(l, 'w', 70, 5); add(l, 'w', 84, 4); add(l, 'C', 104, 2); add(l, 'l', 110, 0);
    add(l, 's', 113, 0); add(l, 'q', 118, 1); add(l, 'w', 124, 0); add(l, 'c', 72, 3);
    return l;
}

Level makeWaveLevel() {
    Level l; l.name = "Zigzag Zone"; l.author = "CubeDash"; l.diff = 1; l.official = true; l.bpm = 140;
    for (int x = 4; x < 12; x += 3) add(l, 's', x, 0);
    add(l, 'W', 14, 2);
    // corridor whose gap steps up and down (5 cells tall, so the wave always has room)
    for (int x = 20; x < 90; x++) {
        int lo = ((x - 20) / 10 % 2) ? 5 : 1;
        for (int y = 0; y < lo; y++) add(l, 'b', x, y);
        for (int y = lo + 6; y <= 10; y++) add(l, 'b', x, y);
    }
    add(l, 'C', 96, 0);
    for (int x : {104, 108}) add(l, 's', x, 0);
    add(l, 'c', 55, 4);
    return l;
}

Level makeBallLevel() {
    Level l; l.name = "Gravity Flip"; l.author = "CubeDash"; l.diff = 2; l.official = true; l.bpm = 150;
    add(l, 's', 8, 0);
    add(l, 'B', 12, 0);
    // floor spikes and roof spikes alternate, so the ball must keep flipping
    for (int x = 26, i = 0; x < 110; x += 14, i++) {
        if (i % 2 == 0) add(l, 's', x, 0);
        else add(l, 'd', x, 10);
    }
    add(l, 'C', 118, 0);
    add(l, 's', 126, 0);
    add(l, 'c', 60, 5);
    return l;
}

}  // namespace cd
