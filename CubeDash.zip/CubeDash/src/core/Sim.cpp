#include "Sim.h"

#include <cmath>

namespace cd {

const float kSpeed[kSpeedCount] = {8.372f, 10.386f, 12.914f, 15.6f, 19.2f};
const char* const kSpeedLabel[kSpeedCount] = {"0.8x", "1x", "1.2x", "1.5x", "1.9x"};

namespace {
constexpr float JUMP = 11.180032f * 60.f / 30.f;
constexpr float GR = 0.958199f * 3600.f / 30.f;
constexpr float BALLG = GR * 0.7f;
constexpr float PADV = 32.f, PINKP = 20.f, PINKO = 15.5f, TV = -30.f;
constexpr float SUP = 50.f, SDN = 40.f, SMAX = 9.f, SMIN = -10.f;
constexpr float E = 1e-6f;
constexpr float FG_TOP = .3f, FG_CEIL = .22f;  // corner forgiveness
constexpr float COIN_R2 = 1.21f;
constexpr float BUF = .12f;

inline float cl(float v, float a, float b) { return std::max(a, std::min(b, v)); }
inline bool ov(float x0, float y0, float x1, float y1, float fx, float fy, float fw, float fh) {
    return fx < x1 && fx + fw > x0 && fy < y1 && fy + fh > y0;
}
struct HB { float a, b, c, d; };
bool hazardBox(char t, HB& h) {
    switch (t) {
        case 's': h = {.42f, .1f, .58f, .5f}; return true;
        case 'n': h = {.4f, .05f, .6f, .28f}; return true;
        case 'd': h = {.42f, .5f, .58f, .9f}; return true;
    }
    return false;
}
}  // namespace

void Sim::setLevel(const Level* lv) {
    L = lv;
    cps.clear(); got.clear(); events.clear();
    won = false; attempt = 0;
    if (L) {
        endX = (float)L->endX();
        totalCoins = L->coins();
    }
}

int Sim::coinsGot() const {
    int n = 0;
    for (auto k : got) n += L && L->get(keyX(k), keyY(k)) == 'c';
    return n;
}

bool Sim::box(float x, float y, float w, float h, Hit* out) const {
    for (int cx = (int)std::floor(x + E); cx <= (int)std::floor(x + w - E); cx++)
        for (int cy = (int)std::floor(y + E); cy <= (int)std::floor(y + h - E); cy++) {
            float sh = solidHeight(L->get(cx, cy));
            if (sh > 0 && y < cy + sh - E) {
                if (out) *out = {cx, cy, cy + sh};
                return true;
            }
        }
    return false;
}

bool Sim::below() const {
    for (int cx = (int)std::floor(P.x + E); cx <= (int)std::floor(P.x + 1 - E); cx++)
        for (int cy = (int)std::floor(P.y) - 1; cy <= (int)std::floor(P.y + E); cy++) {
            float sh = solidHeight(L->get(cx, cy));
            if (sh > 0 && std::fabs(cy + sh - P.y) < E) return true;
        }
    return false;
}

bool Sim::above() const {
    for (int cx = (int)std::floor(P.x + E); cx <= (int)std::floor(P.x + 1 - E); cx++) {
        int cy = (int)std::floor(P.y + 1 + E);
        for (int d = -1; d <= 0; d++)
            if (solidHeight(L->get(cx, cy + d)) > 0 && std::fabs((cy + d) - (P.y + 1)) < E) return true;
    }
    return false;
}

bool Sim::hazards() {
    const bool wave = P.m == Mode::Wave;
    const float off = wave ? .4f : .3f, z = wave ? .2f : .4f;
    const float a = P.x + off, b = P.y + off;
    const int bx = (int)std::floor(P.x), by = (int)std::floor(P.y);
    for (int cx = bx - 2; cx <= bx + 2; cx++)
        for (int cy = by - 2; cy <= by + 3; cy++) {
            char t = L->get(cx, cy);
            if (!t || isSolid(t)) continue;
            int64_t k = cellKey(cx, cy);
            HB h;
            if (hazardBox(t, h)) {
                if (ov(cx + h.a, cy + h.b, cx + h.c, cy + h.d, a, b, z, z)) return true;
            } else if (t == 'w') {
                float nx = cl(cx + .5f, a, a + z), ny = cl(cy + .5f, b, b + z);
                if ((nx - cx - .5f) * (nx - cx - .5f) + (ny - cy - .5f) * (ny - cy - .5f) < .11f) return true;
            } else if ((t == 'p' || t == 'k') && !wave) {
                if (!got.count(k) && ov(cx, cy, cx + 1, cy + .3f, P.x, P.y, 1, 1)) {
                    P.vy = (P.m == Mode::Ball ? -P.gd : 1) * (t == 'p' ? PADV : PINKP);
                    got.insert(k);
                    emit(Event::Pad, cx + .5f, cy + .2f, t);
                }
            } else if ((t == 'o' || t == 'q') && !wave) {
                if (buf > 0 && !got.count(k) && ov(cx - .3f, cy - .3f, cx + 1.3f, cy + 1.3f, P.x, P.y, 1, 1)) {
                    if (P.m == Mode::Ball) {
                        P.gd = -P.gd;
                        P.vy = P.gd * (t == 'o' ? 12.f : 8.f);
                    } else {
                        P.vy = t == 'o' ? JUMP : PINKO;
                    }
                    buf = 0;
                    got.insert(k);
                    emit(Event::Orb, cx + .5f, cy + .5f, t);
                }
            } else if (isPortal(t)) {
                if (ov(cx, cy - 1, cx + 1, cy + 2, P.x, P.y, 1, 1)) {
                    Mode nm = t == 'S' ? Mode::Ship : t == 'B' ? Mode::Ball : t == 'W' ? Mode::Wave : Mode::Cube;
                    if (P.m != nm) {
                        P.m = nm;
                        P.gd = -1;
                        if (nm == Mode::Ship) P.vy = cl(P.vy, -3, 3);
                        else if (nm == Mode::Wave || nm == Mode::Ball) P.vy = 0;
                        emit(Event::Portal, cx + .5f, cy + .5f, t);
                    }
                }
            } else if (t == 'c') {
                if (!got.count(k) && (P.x + .5f - cx - .5f) * (P.x + .5f - cx - .5f) +
                                              (P.y + .5f - cy - .5f) * (P.y + .5f - cy - .5f) < COIN_R2) {
                    got.insert(k);
                    emit(Event::Coin, cx + .5f, cy + .5f, 'c');
                }
            }
        }
    return false;
}

void Sim::die() {
    if (P.dead) return;
    P.dead = true;
    emit(Event::Death, P.x + .5f, P.y + .5f);
}

void Sim::press() { held = true; buf = BUF; }

void Sim::reset(const Checkpoint* c) {
    P = Player();
    startedFromMarker = false;
    if (c) {
        P.x = c->x; P.y = c->y; P.vy = c->vy; P.rot = c->rot; P.m = c->m; P.gd = c->gd;
        t = c->t;
        got = std::unordered_set<int64_t>(c->got.begin(), c->got.end());
    } else {
        got.clear();
        t = 0;
        if (L->hasStart && startFromMarker) {
            P.x = (float)L->startX; P.y = (float)L->startY;
            P.m = (Mode)L->startMode;
            t = P.x / kSpeed[L->speed];
            startedFromMarker = true;
        }
    }
    P.px = P.x; P.py = P.y; P.pr = P.rot;
    won = false; buf = 0; held = false; lastCp = simT; attempt++;
}

void Sim::start(bool useStart) {
    startFromMarker = useStart;
    endX = (float)L->endX();
    totalCoins = L->coins();
    attempt = 0; simT = 0; cps.clear(); events.clear();
    reset(nullptr);
}

void Sim::respawn() {
    events.clear();
    if (practice && !cps.empty()) {
        Checkpoint c = cps.back();
        if (cps.size() > 1 && P.x - c.x < 1.2f) { cps.pop_back(); c = cps.back(); }
        reset(&c);
    } else {
        reset(nullptr);
    }
}

void Sim::step() {
    if (P.dead || won) return;
    P.px = P.x; P.py = P.y; P.pr = P.rot;
    simT += kDT; t += kDT;
    buf = std::max(0.f, buf - kDT);

    const float sp = kSpeed[L->speed];
    const bool ball = P.m == Mode::Ball, ship = P.m == Mode::Ship, wave = P.m == Mode::Wave;
    const bool flipped = ball && P.gd > 0;

    // grounded test
    P.og = flipped ? (P.y >= kCeil - E || above()) : (P.y <= E || below());
    P.cy = P.og ? .06f : P.cy - kDT;

    // --- vertical input / gravity
    if (ship) {
        P.vy = cl(P.vy + (held ? SUP : -SDN) * kDT, SMIN, SMAX);
    } else if (wave) {
        P.vy = held ? sp : -sp;
    } else if (ball) {
        if (buf > 0 && (P.og || P.cy > 0)) {
            P.gd = -P.gd;
            P.vy = P.gd * 2.f;
            P.og = false; P.cy = 0; buf = 0;
            emit(Event::Flip, P.x + .5f, P.y + .5f);
        }
        P.vy = cl(P.vy + P.gd * BALLG * kDT, TV, -TV);
    } else {  // cube
        if ((held && P.og) || (buf > 0 && P.cy > 0)) {
            P.vy = JUMP; P.og = false; P.cy = 0; buf = 0;
            emit(Event::Jump, P.x + .5f, P.y + .05f);
        }
        P.vy = std::max(TV, P.vy - GR * kDT);
    }

    // --- horizontal move + side collision
    P.x += sp * kDT;
    if (wave) {
        // wave: any solid contact is fatal (floor / ceiling are slid along)
        if (box(P.x + .35f, P.y + .35f, .3f, .3f, nullptr)) return die();
    } else {
        Hit b;
        if (box(P.x, P.y, 1, 1, &b)) {
            if (!flipped && P.vy <= 0 && b.top - P.y <= FG_TOP) { P.y = b.top; P.vy = 0; P.og = true; }
            else if (flipped && P.vy >= 0 && P.y + 1 - b.y <= FG_TOP) { P.y = b.y - 1.f; P.vy = 0; P.og = true; }
            else return die();
        }
    }

    // --- vertical move + landing
    const float py = P.y;
    P.y += P.vy * kDT;
    if (P.y <= 0) {
        P.y = 0;
        if (wave) {} else P.vy = std::max(0.f, P.vy);
        if (!flipped) P.og = true;
    } else if ((ship || ball || wave) && P.y > kCeil) {
        P.y = kCeil;
        if (!wave) P.vy = std::min(0.f, P.vy);
        if (flipped) P.og = true;
    }
    if (wave) {
        if (box(P.x + .35f, P.y + .35f, .3f, .3f, nullptr)) return die();
    } else {
        Hit b;
        if (box(P.x, P.y, 1, 1, &b)) {
            if (P.vy <= 0 && py >= b.top - 1e-4f) { P.y = b.top; P.vy = 0; if (!flipped) P.og = true; }
            else if (P.vy > 0 && (ship || ball || P.y + 1 - b.y <= FG_CEIL)) {
                P.y = b.y - 1.f; P.vy = 0; if (flipped) P.og = true;
            } else return die();
        }
    }
    if (hazards()) return die();
    if (P.dead) return;

    // --- visuals bookkeeping
    if (P.og && P.air && P.m == Mode::Cube) emit(Event::Jump, P.x + .5f, P.y + .05f, 'L');
    P.air = !P.og;
    if (ship) P.rot += (-std::atan2(P.vy, sp) * 57.3f - P.rot) * .15f;
    else if (wave) P.rot = -std::atan2(P.vy, sp) * 57.3f;
    else if (ball) P.rot += (P.gd < 0 ? 1.f : -1.f) * 380.f * kDT * (P.og ? 1.f : .5f);
    else if (P.og) P.rot += (std::round(P.rot / 90.f) * 90.f - P.rot) * .12f;
    else P.rot += 463.f * kDT;
    if (++P.tc % 3 == 0) {
        if (!P.og || ship || wave) {
            P.trail.push_back({P.x + .5f, P.y + .5f});
            if (P.trail.size() > (wave ? 40u : 24u)) P.trail.erase(P.trail.begin());
        } else if (!P.trail.empty()) P.trail.erase(P.trail.begin());
    }

    // --- practice checkpoints
    if (practice && simT - lastCp > 1.2f && (P.og || ship || wave)) {
        lastCp = simT;
        Checkpoint c; c.x = P.x; c.y = P.y; c.vy = P.vy; c.rot = P.rot; c.m = P.m; c.gd = P.gd; c.t = t;
        c.got.assign(got.begin(), got.end());
        cps.push_back(std::move(c));
        if (cps.size() > 40) cps.erase(cps.begin());
    }
    if (P.x > endX) { won = true; emit(Event::Win, P.x + .5f, P.y + .5f); }
}

}  // namespace cd
