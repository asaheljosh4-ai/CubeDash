#pragma once
// CubeDash core: deterministic 240 Hz physics. Cube, ship, ball and wave modes.
#include <algorithm>
#include <cstdint>
#include <unordered_set>
#include <utility>
#include <vector>

#include "Level.h"

namespace cd {

constexpr float kDT = 1.f / 240.f;
constexpr int kSpeedCount = 5;
extern const float kSpeed[kSpeedCount];       // blocks per second
extern const char* const kSpeedLabel[kSpeedCount];
constexpr float kCeil = 10.f;                 // highest player y in ship/ball/wave

enum class Mode : char { Cube = 'c', Ship = 's', Ball = 'b', Wave = 'w' };

struct Event {
    enum Type { Jump, Pad, Orb, Portal, Coin, Death, Win, Flip } type;
    float x, y;
    char sub;  // object tag where relevant
};

struct Checkpoint {
    float x = 0, y = 0, vy = 0, rot = 0, t = 0;
    Mode m = Mode::Cube;
    int gd = -1;
    std::vector<int64_t> got;
};

struct Player {
    float x = 0, y = 0, vy = 0, rot = 0;
    float px = 0, py = 0, pr = 0;  // previous step (render interpolation)
    Mode m = Mode::Cube;
    int gd = -1;  // gravity direction (-1 down, +1 up) - ball only
    bool og = true, air = false, dead = false;
    float cy = 0;  // coyote time
    std::vector<std::pair<float, float>> trail;
    int tc = 0;
};

class Sim {
public:
    explicit Sim(const Level* lv = nullptr) { setLevel(lv); }
    void setLevel(const Level* lv);

    // Start (or restart) a run. `useStart` honours the level's start-position marker.
    void start(bool useStart);
    void respawn();  // after death: practice checkpoint or full restart
    void press();    // button pressed (edge)
    void release() { held = false; }
    void step();     // one 1/240 s tick

    // Fully qualified state.
    Player P;
    bool won = false;
    bool practice = false;
    bool startedFromMarker = false;
    float t = 0;        // level time (seconds); music time = level.musicOffset + t
    int attempt = 0;
    float endX = 0;
    int totalCoins = 0;
    std::vector<Checkpoint> cps;
    std::vector<Event> events;  // drained by the app each frame
    std::unordered_set<int64_t> got;
    int coinsGot() const;

    float progress() const { return endX > 0 ? std::min(1.f, std::max(0.f, P.x / endX)) : 0.f; }

private:
    const Level* L = nullptr;
    bool held = false, startFromMarker = false;
    float buf = 0, simT = 0, lastCp = 0;

    struct Hit { int x, y; float top; };
    bool box(float x, float y, float w, float h, Hit* out) const;
    bool below() const;
    bool above() const;
    bool hazards();
    void reset(const Checkpoint* c);
    void die();
    void emit(Event::Type t, float x, float y, char sub = 0) { events.push_back({t, x, y, sub}); }
};

}  // namespace cd
