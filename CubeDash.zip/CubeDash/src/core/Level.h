#pragma once
// CubeDash core: level data model. No third-party dependencies.
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace cd {

constexpr int kMaxY = 60;

inline int64_t cellKey(int x, int y) { return int64_t((uint64_t(uint32_t(x)) << 32) | uint64_t(uint32_t(y))); }
inline int keyX(int64_t k) { return int(int32_t(uint32_t(uint64_t(k) >> 32))); }
inline int keyY(int64_t k) { return int(int32_t(uint32_t(k & 0xffffffffu))); }

// Object tags (identical to the original web engine's save format, plus B and W).
//  b block   l slab   s spike   n mini spike   d roof spike   w saw
//  p pad     k pink pad   o orb   q pink orb   c secret coin
//  C cube portal   S ship portal   B ball portal   W wave portal
struct ObjInfo {
    char tag;
    const char* name;
    const char* group;
};
const std::vector<ObjInfo>& objectTable();
const char* objectName(char tag);
bool isPortal(char t);
bool isSolid(char t);       // block / slab
float solidHeight(char t);  // 1, 0.5 or 0

struct Level {
    std::string name = "Untitled";
    std::string author = "Player";
    std::string musicPath;    // audio file chosen with the music importer
    int diff = 1;             // 0 easy, 1 normal, 2 hard
    int speed = 1;            // index into the speed table
    int bg = 1;               // 0 off, 1 slow, 2 fast
    float bpm = 120.f;
    float musicOffset = 0.f;  // seconds into the song at level x = 0
    bool official = false;    // main-level (dev) flag
    bool hasStart = false;    // start position marker
    int startX = 0, startY = 0;
    char startMode = 'c';     // c cube, s ship, b ball, w wave
    std::unordered_map<int64_t, char> obj;

    char get(int x, int y) const {
        auto it = obj.find(cellKey(x, y));
        return it == obj.end() ? 0 : it->second;
    }
    void set(int x, int y, char t) { obj[cellKey(x, y)] = t; }
    bool erase(int x, int y) { return obj.erase(cellKey(x, y)) > 0; }
    void clear() { obj.clear(); hasStart = false; }
    int coins() const;
    int endX() const;  // finish line x
};

// Text based .cdl level files.
bool saveLevel(const Level& l, const std::string& path);
bool loadLevel(Level& l, const std::string& path);

// Built-in main levels (validated by tests/core_test).
Level makeDemoLevel();
Level makeWaveLevel();
Level makeBallLevel();

}  // namespace cd
