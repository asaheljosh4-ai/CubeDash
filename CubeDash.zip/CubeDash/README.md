# CubeDash (C++)
Native C++17 port of CubeDash_Engine_v3.html: cube, ship, **ball**, **wave**, editor, music importer, FMOD audio.

* `src/core`  – level format + 240 Hz physics (no deps). `tests/core_test.cpp` has a bot proving the 3 main levels are beatable.
* `src/app`   – SDL2 + OpenGL + Dear ImGui: main menu, level select (DEV badge), editor, math placement, music importer, play.
* `src/audio` – FMOD Core (procedural SFX, streamed music, waveform). Without FMOD it builds silent.

## Desktop
    cmake -B build -DFMOD_ROOT=/path/to/FMOD_SDK   # omit FMOD_ROOT for silent build
    cmake --build build -j && ./build/cubedash [--dev]
FMOD SDK is a free download (fmod.com/download, account required).

## Android (A15 = arm64-v8a) - build the APK in the cloud, from your phone
1. Make a free GitHub account, create a repo, upload this folder (zip upload in the browser works).
2. Actions tab > "Build Android APK" > Run workflow. Wait ~10 min.
3. Open the run > Artifacts > CubeDash-apk, download on the phone, install (allow "unknown sources").
Phone audio: the FMOD Android SDK needs extra Java glue, so the APK is silent for now.

## Controls
Play: tap / Space / click = jump / fly / flip / wave up. Pause button top-right. Editor: 1 finger paints, 2 fingers pan+zoom.
