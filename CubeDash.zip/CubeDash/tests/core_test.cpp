// Headless tests for the CubeDash core. Build: see CMake target `core_test`.
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <map>
#include <tuple>

#include "../src/core/Level.h"
#include "../src/core/Sim.h"

using namespace cd;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static bool runInputs(Level& l, bool (*held)(float t, Sim&), float maxT, bool& won) {
    Sim s(&l); s.start(false);
    bool prev = false;
    for (int i = 0; i < int(maxT / kDT) && !s.P.dead && !s.won; i++) {
        bool h = held(s.t, s);
        if (h && !prev) s.press(); else if (!h && prev) s.release();
        prev = h; s.step(); s.events.clear();
    }
    won = s.won;
    return !s.P.dead;
}

// Beam search "bot": proves a level is completable with tap/hold timing only.
static bool beatable(const Level& l, float* tout = nullptr) {
    struct Node { Sim s; bool h; };
    Sim s0(&l); s0.start(false);
    std::vector<Node> beam{{s0, false}};
    const int stepsPerDecision = 6, width = 400;
    for (int d = 0; d < 240 * 90 / stepsPerDecision; d++) {
        std::vector<Node> next;
        for (auto& n : beam)
            for (int a = 0; a < 2; a++) {
                Node m = n;
                bool h = a == 1;
                if (h && !m.h) m.s.press(); else if (!h && m.h) m.s.release();
                m.h = h;
                for (int i = 0; i < stepsPerDecision && !m.s.P.dead && !m.s.won; i++) { m.s.step(); m.s.events.clear(); }
                if (m.s.won) { if (tout) *tout = m.s.t; return true; }
                if (!m.s.P.dead) next.push_back(std::move(m));
            }
        if (next.empty()) return false;
        // dedupe by quantised state, keep the furthest
        std::map<std::tuple<int, int, int, int, int>, size_t> seen;
        std::vector<Node> keep;
        std::sort(next.begin(), next.end(), [](const Node& a, const Node& b) { return a.s.P.x > b.s.P.x; });
        for (auto& n : next) {
            auto k = std::make_tuple(int(n.s.P.y * 8), int(n.s.P.vy), (int)n.s.P.m, n.s.P.gd, (int)n.h);
            if (seen.count(k) && keep.size() > 40) continue;
            seen[k] = 1;
            keep.push_back(std::move(n));
            if ((int)keep.size() >= width) break;
        }
        beam = std::move(keep);
    }
    return false;
}

int main() {
    // 1. empty level: cube runs to the finish without dying
    { Level l; l.set(20, 5, 'c'); bool won; bool alive = runInputs(l, [](float, Sim&) { return false; }, 10, won);
      CHECK(alive); CHECK(won); }
    // 2. spike kills a cube that never jumps
    { Level l; l.set(10, 0, 's'); l.set(40, 5, 'c'); bool won; bool alive = runInputs(l, [](float, Sim&) { return false; }, 10, won);
      CHECK(!alive); CHECK(!won); }
    // 3. holding jump clears a lone spike
    { Level l; l.set(10, 0, 's'); l.set(40, 5, 'c'); bool won;
      bool alive = runInputs(l, [](float, Sim& s) { return s.P.x > 8.2f && s.P.x < 9.2f; }, 10, won);
      CHECK(alive); CHECK(won); }
    // 4. wave: no input slides down along the floor, hold climbs diagonally
    { Level l; l.set(2, 0, 'W'); l.set(60, 5, 'c'); Sim s(&l); s.start(false);
      for (int i = 0; i < 240 * 3; i++) s.step();
      CHECK(s.P.m == Mode::Wave); CHECK(s.P.y == 0.f);
      s.press(); for (int i = 0; i < 120; i++) s.step();
      CHECK(s.P.y > 4.f); CHECK(!s.P.dead); }
    // 5. wave dies on a block
    { Level l; l.set(2, 0, 'W'); l.set(8, 0, 'b'); l.set(8, 1, 'b'); l.set(40, 0, 'c'); bool won;
      bool alive = runInputs(l, [](float, Sim&) { return false; }, 6, won); CHECK(!alive); }
    // 6. ball: tap flips gravity and it ends up at the ceiling
    { Level l; l.set(2, 0, 'B'); l.set(80, 0, 'c'); Sim s(&l); s.start(false);
      for (int i = 0; i < 240; i++) s.step();
      CHECK(s.P.m == Mode::Ball); s.press(); s.release();
      for (int i = 0; i < 240; i++) s.step();
      CHECK(s.P.gd == 1); CHECK(std::fabs(s.P.y - kCeil) < 1e-3f); CHECK(!s.P.dead);
      s.press(); s.release(); for (int i = 0; i < 240; i++) s.step();
      CHECK(s.P.gd == -1); CHECK(s.P.y < 1e-3f); }
    // 7. save / load round trip
    { Level l = makeDemoLevel(); l.hasStart = true; l.startX = 12; l.startY = 0; l.startMode = 'w'; l.musicPath = "x y.ogg"; l.bpm = 133;
      CHECK(saveLevel(l, "/tmp/cd_test.cdl")); Level r; CHECK(loadLevel(r, "/tmp/cd_test.cdl"));
      CHECK(r.obj == l.obj); CHECK(r.name == l.name); CHECK(r.hasStart && r.startX == 12 && r.startMode == 'w');
      CHECK(r.musicPath == "x y.ogg"); CHECK(std::fabs(r.bpm - 133) < 1e-3f); }
    // 8. start-position marker spawns there with matching music time
    { Level l; l.set(40, 0, 'b'); l.hasStart = true; l.startX = 20; l.startY = 0; l.startMode = 'c';
      Sim s(&l); s.start(true); CHECK(s.P.x == 20.f); CHECK(std::fabs(s.t - 20.f / kSpeed[l.speed]) < 1e-4f);
      s.start(false); CHECK(s.P.x == 0.f && s.t == 0.f); }
    // 9. practice mode respawns from a checkpoint with its music time
    { Level l; l.set(30, 0, 's'); l.set(100, 0, 'b'); Sim s(&l); s.practice = true; s.start(false);
      for (int i = 0; i < 240 * 6 && !s.P.dead; i++) s.step();
      CHECK(!s.cps.empty()); CHECK(s.P.dead); if (s.cps.empty()) return 1; float cx = s.cps.back().x, ct = s.cps.back().t;
      s.respawn(); CHECK(s.P.x == cx); CHECK(s.t == ct); CHECK(!s.P.dead); }
    // 10. built-in levels are beatable by the bot
    { Level a = makeDemoLevel(), b = makeWaveLevel(), c = makeBallLevel(); float t;
      bool ra = beatable(a, &t); printf("Stereo Start beatable=%d (%.1fs)\n", ra, t); CHECK(ra);
      bool rb = beatable(b, &t); printf("Zigzag Zone  beatable=%d (%.1fs)\n", rb, t); CHECK(rb);
      bool rc = beatable(c, &t); printf("Gravity Flip beatable=%d (%.1fs)\n", rc, t); CHECK(rc); }
    printf(fails ? "%d FAILED\n" : "ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
